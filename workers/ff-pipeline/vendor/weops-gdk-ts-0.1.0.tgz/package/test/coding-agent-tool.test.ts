// gdk-ts/test/coding-agent-tool.test.ts — Tests for CodingAgent subprocess tool
// CONSOLE-4: CodingAgent Subprocess Tool

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import {
  codingAgentTool,
  _testing,
  type CodingAgentResult,
} from "../src/tools/coding-agent-tool.js";
import { spawn, type ChildProcess } from "child_process";
import { EventEmitter } from "events";

// ============================================================================
// Mocks
// ============================================================================

vi.mock("child_process", () => ({
  spawn: vi.fn(),
}));

// ============================================================================
// Mock Child Process Factory
// ============================================================================

function createMockChildProcess(options: {
  exitCode?: number;
  stdout?: string;
  stderr?: string;
  error?: Error;
}): ChildProcess {
  const child = new EventEmitter() as ChildProcess;

  // Create mock streams
  const stdoutEmitter = new EventEmitter();
  const stderrEmitter = new EventEmitter();

  Object.defineProperty(child, "stdout", {
    value: { on: stdoutEmitter.on.bind(stdoutEmitter), once: stdoutEmitter.once.bind(stdoutEmitter) },
    writable: true,
  });

  Object.defineProperty(child, "stderr", {
    value: { on: stderrEmitter.on.bind(stderrEmitter), once: stderrEmitter.once.bind(stderrEmitter) },
    writable: true,
  });

  Object.defineProperty(child, "kill", {
    value: vi.fn((signal: string) => {
      child.emit("exit", options.exitCode ?? 0, signal);
    }),
    writable: true,
  });

  // Simulate process behavior
  setTimeout(() => {
    if (options.error) {
      child.emit("error", options.error);
      return;
    }

    if (options.stdout) {
      stdoutEmitter.emit("data", Buffer.from(options.stdout));
    }

    if (options.stderr) {
      stderrEmitter.emit("data", Buffer.from(options.stderr));
    }

    child.emit("exit", options.exitCode ?? 0);
  }, 10);

  return child;
}

// ============================================================================
// Test Suite
// ============================================================================

describe("codingAgentTool", () => {
  const mockedSpawn = vi.mocked(spawn);

  beforeEach(() => {
    vi.clearAllMocks();
    // Reset environment
    delete process.env.FIREWORKS_API_KEY;
    delete process.env.EVIDENCE_LEDGER_DSN;
    delete process.env.CODING_AGENT_ACTOR_ID;
    delete process.env.CODING_AGENT_ASSEMBLY_ID;
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("tool definition", () => {
    it("should have correct name and description", () => {
      expect(codingAgentTool.name).toBe("coding_agent");
      expect(codingAgentTool.label).toBe("Coding Agent");
      expect(codingAgentTool.description).toContain(
        "Spawn governed CodingAgent"
      );
    });

    it("should have correct parameters schema", () => {
      const schema = codingAgentTool.parameters;
      expect(schema.type).toBe("object");
      expect(schema.properties).toHaveProperty("taskFile");
      expect(schema.properties).toHaveProperty("model");
      expect(schema.properties).toHaveProperty("workDir");
      expect(schema.required).toContain("taskFile");
    });
  });

  describe("spawn with valid task file", () => {
    it("should spawn coding-agent with correct arguments", async () => {
      const mockChild = createMockChildProcess({
        exitCode: 0,
        stdout: "CodingAgent started\n[TOOL: file_write] /path/to/file.go\nCompleted",
      });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      expect(mockedSpawn).toHaveBeenCalledWith(
        "coding-agent",
        ["-f", "/path/to/task.md"],
        expect.objectContaining({
          stdio: ["ignore", "pipe", "pipe"],
        })
      );
    });

    it("should return structured result on success", async () => {
      const mockChild = createMockChildProcess({
        exitCode: 0,
        stdout: "CodingAgent started\n[TOOL: file_write] /path/to/file.go\nTests passed\nCompleted",
      });
      mockedSpawn.mockReturnValue(mockChild);

      const result = await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      expect(result.details).toMatchObject({
        exitCode: 0,
        filesChanged: ["/path/to/file.go"],
        testsRun: true,
        testsPassed: true,
      });
      expect(result.content[0].type).toBe("text");
      expect(result.content[0].text).toContain("completed successfully");
    });

    it("should return structured result on failure", async () => {
      const mockChild = createMockChildProcess({
        exitCode: 1,
        stdout: "CodingAgent started\nError: something went wrong",
      });
      mockedSpawn.mockReturnValue(mockChild);

      const result = await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      expect(result.details.exitCode).toBe(1);
      expect(result.content[0].text).toContain("exited with code 1");
    });

    it("should use default model when not specified", async () => {
      const mockChild = createMockChildProcess({ exitCode: 0 });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      const spawnCall = mockedSpawn.mock.calls[0];
      const env = spawnCall[2]?.env as NodeJS.ProcessEnv;
      expect(env.CODING_AGENT_MODEL).toBe("kimi-k2p5");
    });

    it("should use provided model override", async () => {
      const mockChild = createMockChildProcess({ exitCode: 0 });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
        model: "gpt-4",
      });

      const spawnCall = mockedSpawn.mock.calls[0];
      const env = spawnCall[2]?.env as NodeJS.ProcessEnv;
      expect(env.CODING_AGENT_MODEL).toBe("gpt-4");
    });

    it("should use default workDir when not specified", async () => {
      const mockChild = createMockChildProcess({ exitCode: 0 });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      const spawnCall = mockedSpawn.mock.calls[0];
      const env = spawnCall[2]?.env as NodeJS.ProcessEnv;
      expect(env.CODING_AGENT_WORK_DIR).toBe(process.cwd());
    });

    it("should use provided workDir override", async () => {
      const mockChild = createMockChildProcess({ exitCode: 0 });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
        workDir: "/custom/work/dir",
      });

      const spawnCall = mockedSpawn.mock.calls[0];
      const env = spawnCall[2]?.env as NodeJS.ProcessEnv;
      expect(env.CODING_AGENT_WORK_DIR).toBe("/custom/work/dir");
    });
  });

  describe("abort signal kills child process", () => {
    it("should send SIGTERM when abort signal is triggered", async () => {
      const mockChild = createMockChildProcess({ exitCode: 0 });
      const killSpy = vi.spyOn(mockChild, "kill");
      mockedSpawn.mockReturnValue(mockChild);

      const controller = new AbortController();

      // Start execution
      const executePromise = codingAgentTool.execute(
        "call_123",
        { taskFile: "/path/to/task.md" },
        controller.signal
      );

      // Abort after a short delay
      setTimeout(() => controller.abort(), 5);

      await executePromise;

      expect(killSpy).toHaveBeenCalledWith("SIGTERM");
    });

    it("should handle abort before process exits", async () => {
      const mockChild = createMockChildProcess({ exitCode: null });
      const killSpy = vi.spyOn(mockChild, "kill");
      mockedSpawn.mockReturnValue(mockChild);

      const controller = new AbortController();
      controller.abort(); // Abort immediately

      const result = await codingAgentTool.execute(
        "call_123",
        { taskFile: "/path/to/task.md" },
        controller.signal
      );

      expect(killSpy).toHaveBeenCalledWith("SIGTERM");
    });
  });

  describe("output parsing (filesChanged extraction)", () => {
    it("should extract single file from [TOOL: file_write] line", () => {
      const output = "[TOOL: file_write] /path/to/file.go";
      const files = _testing.extractFilesChanged(output);
      expect(files).toEqual(["/path/to/file.go"]);
    });

    it("should extract multiple files from multiple [TOOL: file_write] lines", () => {
      const output = `
[TOOL: file_write] /path/to/file1.go
[TOOL: file_write] /path/to/file2.go
[TOOL: file_write] /path/to/file3.go
      `;
      const files = _testing.extractFilesChanged(output);
      expect(files).toEqual([
        "/path/to/file1.go",
        "/path/to/file2.go",
        "/path/to/file3.go",
      ]);
    });

    it("should deduplicate repeated files", () => {
      const output = `
[TOOL: file_write] /path/to/file.go
[TOOL: file_write] /path/to/file.go
      `;
      const files = _testing.extractFilesChanged(output);
      expect(files).toEqual(["/path/to/file.go"]);
    });

    it("should handle case-insensitive matching", () => {
      const output = "[TOOL: FILE_WRITE] /path/to/file.go";
      const files = _testing.extractFilesChanged(output);
      expect(files).toEqual(["/path/to/file.go"]);
    });

    it("should return empty array when no files found", () => {
      const output = "Some output without file write markers";
      const files = _testing.extractFilesChanged(output);
      expect(files).toEqual([]);
    });

    it("should handle paths with spaces", () => {
      const output = "[TOOL: file_write] /path/to/my file.go";
      const files = _testing.extractFilesChanged(output);
      expect(files).toEqual(["/path/to/my file.go"]);
    });
  });

  describe("test detection", () => {
    it("should detect tests run from 'test passed' output", () => {
      const output = "All tests passed successfully";
      expect(_testing.detectTestsRun(output)).toBe(true);
    });

    it("should detect tests run from 'running tests' output", () => {
      const output = "Running tests...";
      expect(_testing.detectTestsRun(output)).toBe(false);
    });

    it("should detect tests run from vitest output", () => {
      const output = "✓ 5 tests passed";
      expect(_testing.detectTestsRun(output)).toBe(true);
    });

    it("should detect tests run from go test output", () => {
      const output = "go test ./...";
      expect(_testing.detectTestsRun(output)).toBe(true);
    });

    it("should not detect tests when no indicators present", () => {
      const output = "Some random output without test references";
      expect(_testing.detectTestsRun(output)).toBe(false);
    });

    it("should detect tests passed when no failures present", () => {
      const output = "All tests passed successfully";
      expect(_testing.detectTestsPassed(output)).toBe(true);
    });

    it("should detect tests failed from 'test failed' output", () => {
      const output = "1 test failed";
      expect(_testing.detectTestsPassed(output)).toBe(false);
    });

    it("should detect tests failed from failure count", () => {
      const output = "Tests: 5 passed, 2 failed";
      expect(_testing.detectTestsPassed(output)).toBe(false);
    });

    it("should detect tests failed from ✗ symbol", () => {
      const output = "✗ test should work";
      expect(_testing.detectTestsPassed(output)).toBe(false);
    });

    it("should return false for testsPassed when no tests run", () => {
      const output = "No test indicators here";
      expect(_testing.detectTestsPassed(output)).toBe(false);
    });
  });

  describe("output truncation", () => {
    it("should return full output when under limit", () => {
      const output = "Line 1\nLine 2\nLine 3";
      expect(_testing.truncateOutput(output, 5)).toBe(output);
    });

    it("should truncate to last N lines when over limit", () => {
      const lines = Array.from({ length: 150 }, (_, i) => `Line ${i + 1}`);
      const output = lines.join("\n");
      const truncated = _testing.truncateOutput(output, 100);
      const truncatedLines = truncated.split("\n");
      expect(truncatedLines.length).toBe(100);
      expect(truncatedLines[0]).toBe("Line 51");
      expect(truncatedLines[99]).toBe("Line 150");
    });

    it("should default to 100 lines", () => {
      const lines = Array.from({ length: 150 }, (_, i) => `Line ${i + 1}`);
      const output = lines.join("\n");
      const truncated = _testing.truncateOutput(output);
      expect(truncated.split("\n").length).toBe(100);
    });
  });

  describe("env passthrough", () => {
    it("should pass through FIREWORKS_API_KEY", async () => {
      process.env.FIREWORKS_API_KEY = "test-api-key";

      const mockChild = createMockChildProcess({ exitCode: 0 });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      const spawnCall = mockedSpawn.mock.calls[0];
      const env = spawnCall[2]?.env as NodeJS.ProcessEnv;
      expect(env.FIREWORKS_API_KEY).toBe("test-api-key");
    });

    it("should pass through EVIDENCE_LEDGER_DSN", async () => {
      process.env.EVIDENCE_LEDGER_DSN = "postgres://localhost/evidence";

      const mockChild = createMockChildProcess({ exitCode: 0 });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      const spawnCall = mockedSpawn.mock.calls[0];
      const env = spawnCall[2]?.env as NodeJS.ProcessEnv;
      expect(env.EVIDENCE_LEDGER_DSN).toBe("postgres://localhost/evidence");
    });

    it("should pass through CODING_AGENT_ACTOR_ID", async () => {
      process.env.CODING_AGENT_ACTOR_ID = "actor_123";

      const mockChild = createMockChildProcess({ exitCode: 0 });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      const spawnCall = mockedSpawn.mock.calls[0];
      const env = spawnCall[2]?.env as NodeJS.ProcessEnv;
      expect(env.CODING_AGENT_ACTOR_ID).toBe("actor_123");
    });

    it("should pass through CODING_AGENT_ASSEMBLY_ID", async () => {
      process.env.CODING_AGENT_ASSEMBLY_ID = "assembly_456";

      const mockChild = createMockChildProcess({ exitCode: 0 });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      const spawnCall = mockedSpawn.mock.calls[0];
      const env = spawnCall[2]?.env as NodeJS.ProcessEnv;
      expect(env.CODING_AGENT_ASSEMBLY_ID).toBe("assembly_456");
    });

    it("should not include undefined env vars", async () => {
      // Ensure env vars are undefined
      delete process.env.FIREWORKS_API_KEY;
      delete process.env.EVIDENCE_LEDGER_DSN;

      const mockChild = createMockChildProcess({ exitCode: 0 });
      mockedSpawn.mockReturnValue(mockChild);

      await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      const spawnCall = mockedSpawn.mock.calls[0];
      const env = spawnCall[2]?.env as NodeJS.ProcessEnv;
      expect(env.FIREWORKS_API_KEY).toBeUndefined();
      expect(env.EVIDENCE_LEDGER_DSN).toBeUndefined();
    });
  });

  describe("streaming updates", () => {
    it("should call onUpdate with partial results during execution", async () => {
      const mockChild = createMockChildProcess({
        exitCode: 0,
        stdout: "Line 1\n[TOOL: file_write] /path/file.go\nLine 3",
      });
      mockedSpawn.mockReturnValue(mockChild);

      const onUpdate = vi.fn();

      await codingAgentTool.execute(
        "call_123",
        { taskFile: "/path/to/task.md" },
        undefined,
        onUpdate
      );

      // Should have been called at least once during streaming
      expect(onUpdate).toHaveBeenCalled();

      // Check the structure of the update
      const lastCall = onUpdate.mock.calls[onUpdate.mock.calls.length - 1][0];
      expect(lastCall).toHaveProperty("content");
      expect(lastCall).toHaveProperty("details");
      expect(lastCall.details).toHaveProperty("exitCode");
    });

    it("should include streaming indicator in update text", async () => {
      const mockChild = createMockChildProcess({
        exitCode: 0,
        stdout: "Some output",
      });
      mockedSpawn.mockReturnValue(mockChild);

      const onUpdate = vi.fn();

      await codingAgentTool.execute(
        "call_123",
        { taskFile: "/path/to/task.md" },
        undefined,
        onUpdate
      );

      const firstCall = onUpdate.mock.calls[0][0];
      expect(firstCall.content[0].text).toContain("Streaming");
    });
  });

  describe("stderr handling", () => {
    it("should include stderr in output", async () => {
      const mockChild = createMockChildProcess({
        exitCode: 0,
        stdout: "stdout content",
        stderr: "stderr content",
      });
      mockedSpawn.mockReturnValue(mockChild);

      const result = await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      expect(result.details.output).toContain("stdout content");
      expect(result.details.output).toContain("stderr content");
    });

    it("should parse filesChanged from stderr too", async () => {
      const mockChild = createMockChildProcess({
        exitCode: 0,
        stdout: "",
        stderr: "[TOOL: file_write] /path/from/stderr.go",
      });
      mockedSpawn.mockReturnValue(mockChild);

      const result = await codingAgentTool.execute("call_123", {
        taskFile: "/path/to/task.md",
      });

      expect(result.details.filesChanged).toContain("/path/from/stderr.go");
    });
  });

  describe("spawn errors", () => {
    it("should throw error when spawn fails", async () => {
      const spawnError = new Error("ENOENT: coding-agent not found");
      const mockChild = createMockChildProcess({ error: spawnError });
      mockedSpawn.mockReturnValue(mockChild);

      await expect(
        codingAgentTool.execute("call_123", {
          taskFile: "/path/to/task.md",
        })
      ).rejects.toThrow("Failed to spawn coding-agent");
    });
  });
});
