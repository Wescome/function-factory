// gdk-ts/test/resilience.test.ts — Tests for retry and circuit breaker
// Per CONSOLE-10: Retry + Circuit Breaker for KernelClient

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { CircuitBreaker, RetryHandler, ResilienceWrapper } from '../src/resilience.js';
import { CircuitOpenError, RetryExhaustedError } from '../src/errors.js';
import { KernelClient, KernelClientOptions } from '../src/client.js';

// ============================================================================
// Mock Helpers
// ============================================================================

function createMockFetch(responses: Array<{ status: number; body?: unknown; error?: boolean }>) {
  let callIndex = 0;
  return vi.fn().mockImplementation(async () => {
    const response = responses[callIndex++];
    if (!response) {
      throw new Error('Unexpected fetch call - no more mock responses');
    }
    
    if (response.error) {
      throw new Error('Network error: ECONNREFUSED');
    }
    
    return {
      ok: response.status >= 200 && response.status < 300,
      status: response.status,
      json: async () => response.body ?? {},
    };
  });
}

function createDelayedMockFetch(responses: Array<{ status: number; delayMs?: number; body?: unknown }>) {
  let callIndex = 0;
  return vi.fn().mockImplementation(async () => {
    const response = responses[callIndex++];
    if (!response) {
      throw new Error('Unexpected fetch call');
    }
    
    if (response.delayMs) {
      await new Promise(resolve => setTimeout(resolve, response.delayMs));
    }
    
    return {
      ok: response.status >= 200 && response.status < 300,
      status: response.status,
      json: async () => response.body ?? {},
    };
  });
}

// Helper to advance timers and wait for promises
async function advanceAndFlush(ms: number) {
  vi.advanceTimersByTime(ms);
  await new Promise(resolve => setImmediate(resolve));
}

// ============================================================================
// Circuit Breaker Tests
// ============================================================================

describe('CircuitBreaker', () => {
  let circuitBreaker: CircuitBreaker;
  let onOpenSpy: ReturnType<typeof vi.fn>;
  let onCloseSpy: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    onOpenSpy = vi.fn();
    onCloseSpy = vi.fn();
    circuitBreaker = new CircuitBreaker(
      { failureThreshold: 5, recoveryTimeoutMs: 100, successThreshold: 1 },
      { onCircuitOpen: onOpenSpy, onCircuitClose: onCloseSpy }
    );
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('CLOSED state (normal operation)', () => {
    it('should allow requests through when closed', async () => {
      const result = await circuitBreaker.execute(async () => 'success');
      expect(result).toBe('success');
      expect(circuitBreaker.currentState).toBe('closed');
    });

    it('should track consecutive failures', async () => {
      for (let i = 0; i < 4; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error(`failure ${i}`);
          });
        } catch {
          // Expected
        }
      }
      expect(circuitBreaker.currentState).toBe('closed');
    });

    it('should reset failure count on success', async () => {
      // 3 failures
      for (let i = 0; i < 3; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error('failure');
          });
        } catch {
          // Expected
        }
      }

      // 1 success resets counter
      await circuitBreaker.execute(async () => 'success');

      // 4 more failures should NOT open circuit (total 4 since last success)
      for (let i = 0; i < 4; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error('failure');
          });
        } catch {
          // Expected
        }
      }

      expect(circuitBreaker.currentState).toBe('closed');
    });
  });

  describe('OPEN state (fail-fast)', () => {
    it('should open circuit after 5 consecutive failures', async () => {
      for (let i = 0; i < 5; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error('failure');
          });
        } catch {
          // Expected
        }
      }

      expect(circuitBreaker.currentState).toBe('open');
      expect(onOpenSpy).toHaveBeenCalledTimes(1);
    });

    it('should fail-fast with CircuitOpenError when circuit is open', async () => {
      // Open the circuit
      for (let i = 0; i < 5; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error('failure');
          });
        } catch {
          // Expected
        }
      }

      // Next request should fail-fast
      const fn = vi.fn().mockResolvedValue('should not be called');
      await expect(circuitBreaker.execute(fn)).rejects.toThrow(CircuitOpenError);
      expect(fn).not.toHaveBeenCalled();
    });

    it('should include recovery time in CircuitOpenError', async () => {
      // Open the circuit
      for (let i = 0; i < 5; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error('failure');
          });
        } catch {
          // Expected
        }
      }

      try {
        await circuitBreaker.execute(async () => 'success');
      } catch (error) {
        expect(error).toBeInstanceOf(CircuitOpenError);
        expect((error as CircuitOpenError).recoveryTimeoutMs).toBe(100);
        expect((error as CircuitOpenError).nextAttemptAt).toBeInstanceOf(Date);
      }
    });
  });

  describe('HALF-OPEN state (probe mode)', () => {
    it('should transition to half-open after recovery timeout', async () => {
      vi.useFakeTimers();

      // Open the circuit
      for (let i = 0; i < 5; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error('failure');
          });
        } catch {
          // Expected
        }
      }

      expect(circuitBreaker.currentState).toBe('open');

      // Advance past recovery timeout
      vi.advanceTimersByTime(150);

      expect(circuitBreaker.currentState).toBe('half-open');
    });

    it('should close circuit on successful probe', async () => {
      vi.useFakeTimers();

      // Open the circuit
      for (let i = 0; i < 5; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error('failure');
          });
        } catch {
          // Expected
        }
      }

      // Advance past recovery timeout
      vi.advanceTimersByTime(150);
      expect(circuitBreaker.currentState).toBe('half-open');

      // Successful probe
      const result = await circuitBreaker.execute(async () => 'success');
      expect(result).toBe('success');
      expect(circuitBreaker.currentState).toBe('closed');
      expect(onCloseSpy).toHaveBeenCalledTimes(1);
    });

    it('should re-open circuit on failed probe', async () => {
      vi.useFakeTimers();

      // Open the circuit
      for (let i = 0; i < 5; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error('failure');
          });
        } catch {
          // Expected
        }
      }

      // Advance past recovery timeout
      vi.advanceTimersByTime(150);
      expect(circuitBreaker.currentState).toBe('half-open');

      // Failed probe
      await expect(
        circuitBreaker.execute(async () => {
          throw new Error('probe failure');
        })
      ).rejects.toThrow('probe failure');

      expect(circuitBreaker.currentState).toBe('open');
      expect(onOpenSpy).toHaveBeenCalledTimes(2); // Once initially, once after probe failure
    });
  });

  describe('reset', () => {
    it('should reset circuit to closed state', async () => {
      // Open the circuit
      for (let i = 0; i < 5; i++) {
        try {
          await circuitBreaker.execute(async () => {
            throw new Error('failure');
          });
        } catch {
          // Expected
        }
      }

      expect(circuitBreaker.currentState).toBe('open');

      circuitBreaker.reset();

      expect(circuitBreaker.currentState).toBe('closed');
      
      // Should allow requests again
      const result = await circuitBreaker.execute(async () => 'success');
      expect(result).toBe('success');
    });
  });
});

// ============================================================================
// Retry Handler Tests
// ============================================================================

describe('RetryHandler', () => {
  let retryHandler: RetryHandler;
  let onRetrySpy: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    onRetrySpy = vi.fn();
    retryHandler = new RetryHandler(
      { maxRetries: 3, baseDelayMs: 10, retryableStatuses: [502, 503, 504] },
      { onRetry: onRetrySpy }
    );
    vi.useFakeTimers({ shouldAdvanceTime: true });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('exponential backoff', () => {
    it('should retry with exponential delays: 10ms, 20ms, 40ms', async () => {
      const fn = vi.fn()
        .mockRejectedValueOnce(new Error('kernel: failed (503)'))
        .mockRejectedValueOnce(new Error('kernel: failed (503)'))
        .mockRejectedValueOnce(new Error('kernel: failed (503)'))
        .mockResolvedValue('success');

      const promise = retryHandler.execute(fn);
      
      // First attempt fails immediately
      expect(fn).toHaveBeenCalledTimes(1);
      
      // Wait for first retry delay (10ms)
      await advanceAndFlush(10);
      expect(fn).toHaveBeenCalledTimes(2);
      expect(onRetrySpy).toHaveBeenNthCalledWith(1, 1, 10);
      
      // Wait for second retry delay (20ms)
      await advanceAndFlush(20);
      expect(fn).toHaveBeenCalledTimes(3);
      expect(onRetrySpy).toHaveBeenNthCalledWith(2, 2, 20);
      
      // Wait for third retry delay (40ms)
      await advanceAndFlush(40);
      expect(fn).toHaveBeenCalledTimes(4);
      expect(onRetrySpy).toHaveBeenNthCalledWith(3, 3, 40);

      const result = await promise;
      expect(result).toBe('success');
    });
  });

  describe('retryable status codes', () => {
    it('should retry on 502, 503, 504', async () => {
      for (const status of [502, 503, 504]) {
        vi.clearAllTimers();
        onRetrySpy.mockClear();
        
        const fn = vi.fn()
          .mockRejectedValueOnce(new Error(`kernel: failed (${status})`))
          .mockResolvedValue('success');

        const promise = retryHandler.execute(fn);
        await advanceAndFlush(10);
        
        const result = await promise;
        expect(result).toBe('success');
        expect(fn).toHaveBeenCalledTimes(2);
      }
    });

    it('should NOT retry on 400, 401, 403, 404, 409', async () => {
      for (const status of [400, 401, 403, 404, 409]) {
        const fn = vi.fn().mockRejectedValue(new Error(`kernel: failed (${status})`));

        await expect(retryHandler.execute(fn)).rejects.toThrow(RetryExhaustedError);
        expect(fn).toHaveBeenCalledTimes(1); // No retries
      }
    });
  });

  describe('network errors', () => {
    it('should retry on network errors (ECONNREFUSED, ETIMEDOUT, ENOTFOUND)', async () => {
      const errors = [
        'Network error: ECONNREFUSED',
        'Network error: ETIMEDOUT',
        'Network error: ENOTFOUND',
        'Connection timeout',
        'Network request failed',
      ];

      for (const errorMsg of errors) {
        const fn = vi.fn()
          .mockRejectedValueOnce(new Error(errorMsg))
          .mockResolvedValue('success');

        const promise = retryHandler.execute(fn);
        await advanceAndFlush(10);
        
        const result = await promise;
        expect(result).toBe('success');
        expect(fn).toHaveBeenCalledTimes(2);
      }
    });
  });

  describe('max retries exhausted', () => {
    it('should throw RetryExhaustedError after 3 retries', async () => {
      const fn = vi.fn().mockRejectedValue(new Error('kernel: failed (503)'));

      const promise = retryHandler.execute(fn);
      
      // Wait for all retry delays
      await advanceAndFlush(10 + 20 + 40);

      await expect(promise).rejects.toThrow(RetryExhaustedError);
      expect(fn).toHaveBeenCalledTimes(4); // Initial + 3 retries
    });

    it('should include attempt count and total delay in error', async () => {
      const fn = vi.fn().mockRejectedValue(new Error('kernel: failed (503)'));

      const promise = retryHandler.execute(fn);
      await advanceAndFlush(10 + 20 + 40);

      try {
        await promise;
      } catch (error) {
        expect(error).toBeInstanceOf(RetryExhaustedError);
        expect((error as RetryExhaustedError).attempts).toBe(4);
        expect((error as RetryExhaustedError).totalDelayMs).toBe(70); // 10 + 20 + 40
      }
    });
  });

  describe('success scenarios', () => {
    it('should succeed on first attempt without retries', async () => {
      const fn = vi.fn().mockResolvedValue('success');

      const result = await retryHandler.execute(fn);
      
      expect(result).toBe('success');
      expect(fn).toHaveBeenCalledTimes(1);
      expect(onRetrySpy).not.toHaveBeenCalled();
    });

    it('should succeed on 2nd attempt after 503', async () => {
      const fn = vi.fn()
        .mockRejectedValueOnce(new Error('kernel: failed (503)'))
        .mockResolvedValue('success');

      const promise = retryHandler.execute(fn);
      await advanceAndFlush(10);
      
      const result = await promise;
      expect(result).toBe('success');
      expect(fn).toHaveBeenCalledTimes(2);
      expect(onRetrySpy).toHaveBeenCalledTimes(1);
      expect(onRetrySpy).toHaveBeenCalledWith(1, 10);
    });
  });
});

// ============================================================================
// ResilienceWrapper Tests (Combined Circuit Breaker + Retry)
// ============================================================================

describe('ResilienceWrapper', () => {
  let wrapper: ResilienceWrapper;

  beforeEach(() => {
    wrapper = new ResilienceWrapper(
      { failureThreshold: 3, recoveryTimeoutMs: 100, successThreshold: 1 },
      { maxRetries: 2, baseDelayMs: 10, retryableStatuses: [503] }
    );
    vi.useFakeTimers({ shouldAdvanceTime: true });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('should use retry within circuit breaker', async () => {
    const fn = vi.fn()
      .mockRejectedValueOnce(new Error('kernel: failed (503)'))
      .mockResolvedValue('success');

    const promise = wrapper.execute(fn);
    await advanceAndFlush(10);
    
    const result = await promise;
    expect(result).toBe('success');
    expect(fn).toHaveBeenCalledTimes(2);
    expect(wrapper.circuitState).toBe('closed');
  });

  it('should count retry failures toward circuit breaker threshold', async () => {
    // Each operation retries 2 times, so 1 operation = 3 failures max
    const fn = vi.fn().mockRejectedValue(new Error('kernel: failed (503)'));

    // First operation: initial + 2 retries = 3 failures
    const promise1 = wrapper.execute(fn);
    await advanceAndFlush(10 + 20);
    await expect(promise1).rejects.toThrow(RetryExhaustedError);
    
    // Circuit should be open (3 failures reached threshold)
    expect(wrapper.circuitState).toBe('open');
  });
});

// ============================================================================
// KernelClient Integration Tests
// ============================================================================

describe('KernelClient with Resilience', () => {
  let client: KernelClient;
  let mockFetch: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('createWorkOrder', () => {
    it('should retry and succeed on 2nd attempt after 503', async () => {
      mockFetch = createMockFetch([
        { status: 503 },
        { status: 200, body: { work_order_id: 'wo_123' } },
      ]);

      const onRetry = vi.fn();
      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        assemblyId: 'test-assembly',
        retry: { maxRetries: 3, baseDelayMs: 10, retryableStatuses: [502, 503, 504] },
        eventHandlers: { onRetry },
      });
      client.fetchFn = mockFetch;

      const promise = client.createWorkOrder({
        assemblyId: 'test-assembly',
        purposeId: 'purpose_123',
        workType: 'TEST',
        autonomyTier: 'T0',
        idempotencyKey: 'idem_123',
      });

      await advanceAndFlush(10);
      
      const result = await promise;
      expect(result).toBe('wo_123');
      expect(mockFetch).toHaveBeenCalledTimes(2);
      expect(onRetry).toHaveBeenCalledTimes(1);
      expect(onRetry).toHaveBeenCalledWith(1, 10);
    });

    it('should exhaust retries after 3 failures and throw', async () => {
      mockFetch = createMockFetch([
        { status: 503 },
        { status: 503 },
        { status: 503 },
        { status: 503 },
      ]);

      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        retry: { maxRetries: 3, baseDelayMs: 10 },
      });
      client.fetchFn = mockFetch;

      const promise = client.createWorkOrder({
        assemblyId: 'test-assembly',
        purposeId: 'purpose_123',
        workType: 'TEST',
        autonomyTier: 'T0',
        idempotencyKey: 'idem_123',
      });

      // Wait for all retry delays
      await advanceAndFlush(10 + 20 + 40);

      await expect(promise).rejects.toThrow(RetryExhaustedError);
      expect(mockFetch).toHaveBeenCalledTimes(4); // Initial + 3 retries
    });

    it('should open circuit after 5 consecutive failures', async () => {
      mockFetch = createMockFetch([
        { status: 503 }, { status: 503 }, { status: 503 }, // First call + 2 retries
        { status: 503 }, { status: 503 }, { status: 503 }, // Second call + 2 retries
        { status: 503 }, { status: 503 }, { status: 503 }, // Third call + 2 retries
      ]);

      const onCircuitOpen = vi.fn();
      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        circuitBreaker: { failureThreshold: 5, recoveryTimeoutMs: 100 },
        retry: { maxRetries: 2, baseDelayMs: 10 },
        eventHandlers: { onCircuitOpen },
      });
      client.fetchFn = mockFetch;

      // First call: 3 failures (initial + 2 retries)
      try {
        const promise1 = client.createWorkOrder({
          assemblyId: 'test-assembly',
          purposeId: 'purpose_1',
          workType: 'TEST',
          autonomyTier: 'T0',
          idempotencyKey: 'idem_1',
        });
        await advanceAndFlush(10 + 20);
        await promise1;
      } catch {
        // Expected
      }

      expect(client.circuitState).toBe('closed'); // 3 failures, threshold is 5

      // Second call: 3 more failures (total 6)
      try {
        const promise2 = client.createWorkOrder({
          assemblyId: 'test-assembly',
          purposeId: 'purpose_2',
          workType: 'TEST',
          autonomyTier: 'T0',
          idempotencyKey: 'idem_2',
        });
        await advanceAndFlush(10 + 20);
        await promise2;
      } catch {
        // Expected
      }

      expect(client.circuitState).toBe('open');
      expect(onCircuitOpen).toHaveBeenCalledTimes(1);
    });

    it('should block requests when circuit is open (fail-fast, no network call)', async () => {
      mockFetch = createMockFetch([
        { status: 503 }, { status: 503 }, { status: 503 },
        { status: 503 }, { status: 503 }, { status: 503 },
      ]);

      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        circuitBreaker: { failureThreshold: 5, recoveryTimeoutMs: 1000 },
        retry: { maxRetries: 2, baseDelayMs: 10 },
      });
      client.fetchFn = mockFetch;

      // Open the circuit
      for (let i = 0; i < 2; i++) {
        try {
          const promise = client.createWorkOrder({
            assemblyId: 'test-assembly',
            purposeId: `purpose_${i}`,
            workType: 'TEST',
            autonomyTier: 'T0',
            idempotencyKey: `idem_${i}`,
          });
          await advanceAndFlush(10 + 20);
          await promise;
        } catch {
          // Expected
        }
      }

      expect(client.circuitState).toBe('open');
      const callsBefore = mockFetch.mock.calls.length;

      // Next request should fail-fast
      await expect(
        client.createWorkOrder({
          assemblyId: 'test-assembly',
          purposeId: 'purpose_blocked',
          workType: 'TEST',
          autonomyTier: 'T0',
          idempotencyKey: 'idem_blocked',
        })
      ).rejects.toThrow(CircuitOpenError);

      // No additional fetch calls
      expect(mockFetch.mock.calls.length).toBe(callsBefore);
    });

    it('should transition to half-open after recovery timeout', async () => {
      mockFetch = createMockFetch([
        { status: 503 }, { status: 503 }, { status: 503 },
        { status: 503 }, { status: 503 }, { status: 503 },
      ]);

      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        circuitBreaker: { failureThreshold: 5, recoveryTimeoutMs: 100 },
        retry: { maxRetries: 2, baseDelayMs: 10 },
      });
      client.fetchFn = mockFetch;

      // Open the circuit
      for (let i = 0; i < 2; i++) {
        try {
          const promise = client.createWorkOrder({
            assemblyId: 'test-assembly',
            purposeId: `purpose_${i}`,
            workType: 'TEST',
            autonomyTier: 'T0',
            idempotencyKey: `idem_${i}`,
          });
          await advanceAndFlush(10 + 20);
          await promise;
        } catch {
          // Expected
        }
      }

      expect(client.circuitState).toBe('open');

      // Advance past recovery timeout
      vi.advanceTimersByTime(150);

      expect(client.circuitState).toBe('half-open');
    });

    it('should close circuit on successful probe', async () => {
      mockFetch = createMockFetch([
        { status: 503 }, { status: 503 }, { status: 503 },
        { status: 503 }, { status: 503 }, { status: 503 },
        { status: 200, body: { work_order_id: 'wo_success' } },
      ]);

      const onCircuitClose = vi.fn();
      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        circuitBreaker: { failureThreshold: 5, recoveryTimeoutMs: 100, successThreshold: 1 },
        retry: { maxRetries: 2, baseDelayMs: 10 },
        eventHandlers: { onCircuitClose },
      });
      client.fetchFn = mockFetch;

      // Open the circuit
      for (let i = 0; i < 2; i++) {
        try {
          const promise = client.createWorkOrder({
            assemblyId: 'test-assembly',
            purposeId: `purpose_${i}`,
            workType: 'TEST',
            autonomyTier: 'T0',
            idempotencyKey: `idem_${i}`,
          });
          await advanceAndFlush(10 + 20);
          await promise;
        } catch {
          // Expected
        }
      }

      expect(client.circuitState).toBe('open');

      // Advance past recovery timeout
      vi.advanceTimersByTime(150);
      expect(client.circuitState).toBe('half-open');

      // Successful probe
      const result = await client.createWorkOrder({
        assemblyId: 'test-assembly',
        purposeId: 'purpose_probe',
        workType: 'TEST',
        autonomyTier: 'T0',
        idempotencyKey: 'idem_probe',
      });

      expect(result).toBe('wo_success');
      expect(client.circuitState).toBe('closed');
      expect(onCircuitClose).toHaveBeenCalledTimes(1);
    });

    it('should NOT retry on 400/401/403 errors', async () => {
      for (const status of [400, 401, 403]) {
        mockFetch = createMockFetch([{ status }]);

        const onRetry = vi.fn();
        client = new KernelClient({
          endpoint: 'http://kernel.test',
          authToken: 'test-token',
          retry: { maxRetries: 3, baseDelayMs: 10 },
          eventHandlers: { onRetry },
        });
        client.fetchFn = mockFetch;

        await expect(
          client.createWorkOrder({
            assemblyId: 'test-assembly',
            purposeId: 'purpose_123',
            workType: 'TEST',
            autonomyTier: 'T0',
            idempotencyKey: 'idem_123',
          })
        ).rejects.toThrow();

        expect(mockFetch).toHaveBeenCalledTimes(1); // No retries
        expect(onRetry).not.toHaveBeenCalled();
      }
    });

    it('should preserve idempotency key across retries', async () => {
      mockFetch = createMockFetch([
        { status: 503 },
        { status: 200, body: { work_order_id: 'wo_123' } },
      ]);

      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        retry: { maxRetries: 3, baseDelayMs: 10 },
      });
      client.fetchFn = mockFetch;

      const promise = client.createWorkOrder({
        assemblyId: 'test-assembly',
        purposeId: 'purpose_123',
        workType: 'TEST',
        autonomyTier: 'T0',
        idempotencyKey: 'idem_preserved_123',
      });

      await advanceAndFlush(10);
      await promise;

      // Both calls should have the same idempotency key
      expect(mockFetch).toHaveBeenCalledTimes(2);
      const firstCall = mockFetch.mock.calls[0][1] as { headers: Record<string, string> };
      const secondCall = mockFetch.mock.calls[1][1] as { headers: Record<string, string> };
      
      expect(firstCall.headers['X-Idempotency-Key']).toBe('idem_preserved_123');
      expect(secondCall.headers['X-Idempotency-Key']).toBe('idem_preserved_123');
    });
  });

  describe('evaluatePolicy', () => {
    it('should use retry and circuit breaker for policy evaluation', async () => {
      mockFetch = createMockFetch([
        { status: 503 },
        { status: 200, body: { policy_decision_id: 'pd_123', decision: 'PERMIT', evaluated_at: new Date().toISOString() } },
      ]);

      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        retry: { maxRetries: 3, baseDelayMs: 10 },
      });
      client.fetchFn = mockFetch;

      const promise = client.evaluatePolicy({
        subject: { subjectId: 'user_123' },
        action: { actionId: 'action_123' },
        resource: { resourceType: 'resource_123' },
        context: {
          workOrderId: 'wo_123',
          assemblyId: 'test-assembly',
          autonomyTier: 'T0',
        },
      });

      await advanceAndFlush(10);
      
      const result = await promise;
      expect(result.decision).toBe('PERMIT');
      expect(mockFetch).toHaveBeenCalledTimes(2);
    });
  });

  describe('getWorkOrder', () => {
    it('should use retry and circuit breaker for get work order', async () => {
      mockFetch = createMockFetch([
        { status: 504 },
        { status: 200, body: { work_order_id: 'wo_123', status: 'RUNNING', autonomy_tier: 'T0' } },
      ]);

      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        retry: { maxRetries: 3, baseDelayMs: 10 },
      });
      client.fetchFn = mockFetch;

      const promise = client.getWorkOrder('wo_123');
      await advanceAndFlush(10);
      
      const result = await promise;
      expect(result.workOrderId).toBe('wo_123');
      expect(mockFetch).toHaveBeenCalledTimes(2);
    });
  });

  describe('getEvidence', () => {
    it('should use retry and circuit breaker for get evidence', async () => {
      mockFetch = createMockFetch([
        { status: 502 },
        { status: 200, body: { evidence_id: 'ev_123', data: 'test' } },
      ]);

      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        retry: { maxRetries: 3, baseDelayMs: 10 },
      });
      client.fetchFn = mockFetch;

      const promise = client.getEvidence('ev_123');
      await advanceAndFlush(10);
      
      const result = await promise;
      expect(result.evidence_id).toBe('ev_123');
      expect(mockFetch).toHaveBeenCalledTimes(2);
    });
  });

  describe('circuitState visibility', () => {
    it('should expose circuit state via client.circuitState', async () => {
      mockFetch = createMockFetch([
        { status: 503 }, { status: 503 }, { status: 503 },
        { status: 503 }, { status: 503 }, { status: 503 },
      ]);

      client = new KernelClient({
        endpoint: 'http://kernel.test',
        authToken: 'test-token',
        circuitBreaker: { failureThreshold: 5, recoveryTimeoutMs: 100 },
        retry: { maxRetries: 2, baseDelayMs: 10 },
      });
      client.fetchFn = mockFetch;

      expect(client.circuitState).toBe('closed');

      // Open the circuit
      for (let i = 0; i < 2; i++) {
        try {
          const promise = client.createWorkOrder({
            assemblyId: 'test-assembly',
            purposeId: `purpose_${i}`,
            workType: 'TEST',
            autonomyTier: 'T0',
            idempotencyKey: `idem_${i}`,
          });
          await advanceAndFlush(10 + 20);
          await promise;
        } catch {
          // Expected
        }
      }

      expect(client.circuitState).toBe('open');

      // Advance past recovery timeout
      vi.advanceTimersByTime(150);
      expect(client.circuitState).toBe('half-open');
    });
  });

  describe('legacy constructor compatibility', () => {
    it('should support legacy (endpoint, authToken, assemblyId) constructor', async () => {
      mockFetch = createMockFetch([
        { status: 200, body: { work_order_id: 'wo_123' } },
      ]);

      client = new KernelClient('http://kernel.test', 'test-token', 'test-assembly');
      client.fetchFn = mockFetch;

      const result = await client.createWorkOrder({
        assemblyId: 'test-assembly',
        purposeId: 'purpose_123',
        workType: 'TEST',
        autonomyTier: 'T0',
        idempotencyKey: 'idem_123',
      });

      expect(result).toBe('wo_123');
      expect(client.circuitState).toBe('closed');
    });
  });
});
