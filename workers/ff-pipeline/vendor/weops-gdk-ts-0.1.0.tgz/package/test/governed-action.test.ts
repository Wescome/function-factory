// test/governed-action.test.ts — Acceptance tests AT-GDK-TS-01 through AT-GDK-TS-09
// Per SDD-GDK §4.3.4. Uses Bun test runner.

import { describe, test, expect, afterEach } from "bun:test";
import { GovernedService } from "../src/service.js";
import { Tier } from "../src/types.js";
import type { GovernedAction, GovernedConfig } from "../src/types.js";
import {
  GovernanceError,
  AuthorizationError,
  FidelityInsufficientError,
  EscalationTimeoutError,
  PolicyViolationError,
} from "../src/errors.js";
import { MockGovernance, createMockService } from "../src/testing/index.js";
import { governed } from "../src/decorators.js";

// ---------------------------------------------------------------------------
// Helper: create a service wired to a mock
// ---------------------------------------------------------------------------

function setup(mock: MockGovernance) {
  return createMockService(GovernedService as unknown as new (...args: unknown[]) => GovernedService, mock);
}

// ---------------------------------------------------------------------------
// AT-GDK-TS-01: T0 PERMIT -> action executes
// ---------------------------------------------------------------------------
describe("AT-GDK-TS-01: T0 PERMIT -> action executes", () => {
  test("autonomous action permitted and executed", async () => {
    const mock = new MockGovernance();
    const svc = setup(mock);

    let executed = false;

    await svc.executeGovernedAction({
      intentClass: "patient.read_vitals",
      tier: Tier.AUTONOMOUS,
      context: { patientId: "p-123" },
      idempotencyKey: "at01-key-1",
      action: async () => {
        executed = true;
      },
    });

    expect(executed).toBe(true);
    expect(mock.pdpCallCount()).toBe(1);
    expect(mock.workOrderCount()).toBe(1);
    mock.verify();
    mock.close();
  });
});

// ---------------------------------------------------------------------------
// AT-GDK-TS-02: BLOCKED -> DENY -> action NOT executed -> AuthorizationError
// ---------------------------------------------------------------------------
describe("AT-GDK-TS-02: BLOCKED -> DENY -> AuthorizationError", () => {
  test("blocked tier results in denial and action not executed", async () => {
    const mock = new MockGovernance();
    mock.expectDeny("WAC_A");
    const svc = setup(mock);

    let executed = false;

    try {
      await svc.executeGovernedAction({
        intentClass: "patient.delete_record",
        tier: Tier.BLOCKED,
        idempotencyKey: "at02-key-1",
        action: async () => {
          executed = true;
        },
      });
      // Should not reach here
      expect(true).toBe(false);
    } catch (err) {
      expect(err).toBeInstanceOf(AuthorizationError);
      expect((err as AuthorizationError).code).toBe("WAC_A");
    }

    expect(executed).toBe(false);
    mock.verify();
    mock.close();
  });
});

// ---------------------------------------------------------------------------
// AT-GDK-TS-03: T2 -> blocks -> approval -> executes
// ---------------------------------------------------------------------------
describe("AT-GDK-TS-03: T2 -> blocks -> approval -> executes", () => {
  test("expert approval tier blocks until approval then executes", async () => {
    const mock = new MockGovernance();
    mock.expectApprovalGrantedAfter(50); // 50ms delay
    const svc = setup(mock);

    let executed = false;

    await svc.executeGovernedAction({
      intentClass: "patient.modify_treatment",
      tier: Tier.EXPERT_APPROVAL,
      idempotencyKey: "at03-key-1",
      action: async () => {
        executed = true;
      },
    });

    expect(executed).toBe(true);
    // Should have polled at least once
    const pollCalls = mock.getCalls().filter(
      (c) => c.endpoint === "GET /v1/workorders/{id}",
    );
    expect(pollCalls.length).toBeGreaterThanOrEqual(1);
    mock.verify();
    mock.close();
  });
});

// ---------------------------------------------------------------------------
// AT-GDK-TS-04: Reversible action -> forward executes
// ---------------------------------------------------------------------------
describe("AT-GDK-TS-04: Reversible action -> forward executes", () => {
  test("reversible action executes forward function", async () => {
    const mock = new MockGovernance();
    const svc = setup(mock);

    let forwardExecuted = false;

    await svc.executeReversibleAction({
      intentClass: "patient.update_medication",
      forwardFunc: async () => {
        forwardExecuted = true;
        return { medicationId: "med-456" };
      },
      reverseFunc: async (_result) => {
        // Reverse would undo the medication update
      },
    });

    expect(forwardExecuted).toBe(true);
    expect(mock.workOrderCount()).toBe(1);
    mock.verify();
    mock.close();
  });
});

// ---------------------------------------------------------------------------
// AT-GDK-TS-05: Missing idempotency key -> error before kernel call
// ---------------------------------------------------------------------------
describe("AT-GDK-TS-05: Missing idempotency key -> error before kernel call", () => {
  test("missing idempotency key throws GovernanceError before any kernel call", async () => {
    const mock = new MockGovernance();
    const svc = setup(mock);

    try {
      await svc.executeGovernedAction({
        intentClass: "patient.read_vitals",
        tier: Tier.AUTONOMOUS,
        idempotencyKey: "", // empty = missing
        action: async () => {},
      });
      expect(true).toBe(false);
    } catch (err) {
      expect(err).toBeInstanceOf(GovernanceError);
      expect((err as GovernanceError).code).toBe("GDK_MISSING_IDEMPOTENCY_KEY");
    }

    // No kernel calls should have been made
    expect(mock.callCount()).toBe(0);
    expect(mock.workOrderCount()).toBe(0);
    mock.close();
  });
});

// ---------------------------------------------------------------------------
// AT-GDK-TS-06: Kernel unreachable -> fail closed -> AuthorizationError
// ---------------------------------------------------------------------------
describe("AT-GDK-TS-06: Kernel unreachable -> fail closed -> AuthorizationError", () => {
  test("kernel unreachable results in denial, action not executed", async () => {
    const mock = new MockGovernance();
    const svc = setup(mock);

    // Override fetchFn to simulate network failure
    svc.kernelClient.fetchFn = async () => {
      throw new Error("ECONNREFUSED: connection refused");
    };

    let executed = false;

    try {
      await svc.executeGovernedAction({
        intentClass: "patient.read_vitals",
        tier: Tier.AUTONOMOUS,
        idempotencyKey: "at06-key-1",
        action: async () => {
          executed = true;
        },
      });
      expect(true).toBe(false);
    } catch (err) {
      expect(err).toBeInstanceOf(AuthorizationError);
      expect((err as AuthorizationError).code).toBe("WAC_A");
      expect((err as AuthorizationError).message).toContain("kernel unreachable");
    }

    expect(executed).toBe(false);
    mock.close();
  });
});

// ---------------------------------------------------------------------------
// AT-GDK-TS-07: Batch atomic + one DENY -> all rolled back
// ---------------------------------------------------------------------------
describe("AT-GDK-TS-07: Batch atomic + one DENY -> all rolled back", () => {
  test("atomic batch with one DENY prevents all subsequent actions", async () => {
    // We need a mock that permits first, then denies second.
    // Use a custom mock that tracks call count.
    const mock = new MockGovernance();
    const svc = setup(mock);

    let callCount = 0;
    const originalFetch = svc.kernelClient.fetchFn;

    // Wrap fetch to DENY the second PDP call
    svc.kernelClient.fetchFn = async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = typeof input === "string" ? input : input.toString();
      const method = init?.method ?? "GET";

      if (method === "POST" && /\/v1\/pdp\/decide$/.test(url)) {
        callCount++;
        if (callCount >= 2) {
          // Second PDP call: DENY
          return new Response(
            JSON.stringify({
              policy_decision_id: `pd_deny_${callCount}`,
              decision: "DENY",
              evaluated_at: new Date().toISOString(),
              reasons: [{ summary: "denied by test" }],
            }),
            { status: 200, headers: { "Content-Type": "application/json" } },
          );
        }
      }
      return originalFetch(input, init);
    };

    const executed: number[] = [];

    const actions: GovernedAction[] = [
      {
        intentClass: "patient.action_a",
        tier: Tier.AUTONOMOUS,
        idempotencyKey: "at07-key-a",
        action: async () => {
          executed.push(0);
        },
      },
      {
        intentClass: "patient.action_b",
        tier: Tier.AUTONOMOUS,
        idempotencyKey: "at07-key-b",
        action: async () => {
          executed.push(1);
        },
      },
      {
        intentClass: "patient.action_c",
        tier: Tier.AUTONOMOUS,
        idempotencyKey: "at07-key-c",
        action: async () => {
          executed.push(2);
        },
      },
    ];

    try {
      await svc.executeBatchGovernedActions(actions, {
        transactionSemantics: "atomic",
      });
      expect(true).toBe(false);
    } catch (err) {
      expect(err).toBeInstanceOf(AuthorizationError);
    }

    // First action executed, second denied, third never reached (atomic)
    expect(executed).toEqual([0]);
    mock.close();
  });
});

// ---------------------------------------------------------------------------
// AT-GDK-TS-08: Async decorator with Promise<void>
// ---------------------------------------------------------------------------
describe("AT-GDK-TS-08: Decorator applied to async method returning Promise<void>", () => {
  test("governed decorator works with async methods", async () => {
    const mock = new MockGovernance();

    class TestService extends GovernedService {
      executed = false;

      @governed({
        intentClass: "patient.check_vitals",
        tier: Tier.AUTONOMOUS,
        idempotencyKeyFn: () => "at08-key-1",
      })
      async checkVitals(): Promise<void> {
        this.executed = true;
      }
    }

    const opts = mock.serviceOptions();
    const svc = new TestService(opts);
    opts._mockSetup(svc.kernelClient);

    await svc.checkVitals();

    expect(svc.executed).toBe(true);
    expect(mock.pdpCallCount()).toBe(1);
    mock.verify();
    mock.close();
  });
});

// ---------------------------------------------------------------------------
// AT-GDK-TS-09: GovernanceError subclasses are instanceof-checkable
// ---------------------------------------------------------------------------
describe("AT-GDK-TS-09: GovernanceError subclasses are instanceof-checkable", () => {
  test("all error subclasses pass instanceof checks", () => {
    const govErr = new GovernanceError({ code: "GDK_TEST", message: "test" });
    const authErr = new AuthorizationError({ code: "WAC_A", message: "denied" });
    const fidErr = new FidelityInsufficientError({
      code: "WAC_P",
      message: "insufficient",
      missingFields: ["field_a"],
    });
    const escErr = new EscalationTimeoutError({
      code: "GDK_ESCALATION_TIMEOUT",
      message: "timed out",
      timeoutDurationMs: 5000,
    });
    const polErr = new PolicyViolationError({
      code: "WAC_C",
      message: "violated",
      policyId: "pol-1",
      policyName: "test-policy",
      violationDetails: "detail",
    });

    // Each is instanceof its own class
    expect(govErr).toBeInstanceOf(GovernanceError);
    expect(authErr).toBeInstanceOf(AuthorizationError);
    expect(fidErr).toBeInstanceOf(FidelityInsufficientError);
    expect(escErr).toBeInstanceOf(EscalationTimeoutError);
    expect(polErr).toBeInstanceOf(PolicyViolationError);

    // All subclasses are instanceof GovernanceError
    expect(authErr).toBeInstanceOf(GovernanceError);
    expect(fidErr).toBeInstanceOf(GovernanceError);
    expect(escErr).toBeInstanceOf(GovernanceError);
    expect(polErr).toBeInstanceOf(GovernanceError);

    // All are instanceof Error
    expect(govErr).toBeInstanceOf(Error);
    expect(authErr).toBeInstanceOf(Error);
    expect(fidErr).toBeInstanceOf(Error);
    expect(escErr).toBeInstanceOf(Error);
    expect(polErr).toBeInstanceOf(Error);

    // Cross-class checks: NOT instanceof each other
    expect(authErr).not.toBeInstanceOf(FidelityInsufficientError);
    expect(fidErr).not.toBeInstanceOf(AuthorizationError);
    expect(escErr).not.toBeInstanceOf(PolicyViolationError);

    // Verify specific fields
    expect(fidErr.missingFields).toEqual(["field_a"]);
    expect(escErr.timeoutDurationMs).toBe(5000);
    expect(polErr.policyId).toBe("pol-1");
    expect(polErr.policyName).toBe("test-policy");
  });
});
