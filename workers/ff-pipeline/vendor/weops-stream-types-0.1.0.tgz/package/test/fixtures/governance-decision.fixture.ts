// test/fixtures/governance-decision.fixture.ts - GovernanceDataPart with PERMIT + obligations

import type { GovernanceDataPart } from "../../src/stream/data-parts.ts";
import type { WeOpsDataPart } from "../../src/stream/data-parts.ts";

export const GOVERNANCE_PERMIT: GovernanceDataPart = {
  policy_decision_id: "pd_abc123def456gh78",
  decision: "PERMIT",
  reasons: [
    {
      code: "ROLE_MATCH",
      severity: "INFO",
      summary: "Role matches required access level",
      detail: "MEMBER role has access to TREATMENT.DISCHARGE_COORDINATION",
      next_steps: null,
    },
  ],
  obligations: [
    {
      type: "REQUIRE_EVIDENCE_BUNDLE",
      value: { retention_days: 365 },
      satisfied: false,
    },
    {
      type: "LOG_LEVEL",
      value: { level: "DETAILED" },
      satisfied: false,
    },
  ],
  escalation_rung: null,
  escalation_trigger: null,
  work_order_id: "wo_abc123def456gh78",
  invocation_id: null,
  tool_id: null,
  timestamp: "2026-02-16T12:00:01.500Z",
};

export const GOVERNANCE_PERMIT_DATA_PART: WeOpsDataPart = {
  type: "data-governance",
  data: GOVERNANCE_PERMIT,
};
