// test/fixtures/envelope-request.fixture.ts - Valid Envelope fixture

import type { Envelope } from "../../src/kernel/envelope.ts";

export const VALID_ENVELOPE: Envelope = {
  envelope_id: "env_abc123def456gh78",
  correlation_id: "env_xyz789uvw012ab34",
  timestamp: "2026-02-16T12:00:00.000Z",
  source: {
    channel: "web",
    channel_version: "1.0.0",
    device_class: "desktop",
    capabilities: ["streaming", "markdown"],
  },
  session: {
    session_id: "ses_abc123def456gh78",
    identity_id: "usr-001",
    workspace_id: "ws_primary_care",
    active_role: "MEMBER",
    product_assembly: "tpl_abc123def456gh78",
  },
  intent: {
    intent_type: "workorder.create",
    payload: { description: "Coordinate patient discharge" },
  },
  constraint_ctx: {
    governance_level: "G2",
    autonomy_tier: "T1",
    risk_tier: "R2",
    purpose: "TREATMENT.CARE_COORDINATION",
    classification: "CONFIDENTIAL",
  },
};
