// test/fixtures/work-order-stream.fixture.ts - WorkOrderDataPart lifecycle sequence

import type { WorkOrderDataPart } from "../../src/stream/data-parts.ts";
import type { WeOpsDataPart } from "../../src/stream/data-parts.ts";

const BASE: WorkOrderDataPart = {
  work_order_id: "wo_abc123def456gh78",
  parent_work_order_id: null,
  status: "DRAFT",
  primary_purpose: "TREATMENT.DISCHARGE_COORDINATION",
  acting_role: "MEMBER",
  stakeholders: ["usr-001", "usr-002"],
  autonomy_tier: "T1",
  risk_tier: "R2",
  decision_rule_on_conflict: "ESCALATE_WITH_OPTIONS_MEMO",
  compensation_sub_state: null,
  pending_approvals: [],
  timestamp: "2026-02-16T12:00:00.000Z",
};

export const WORK_ORDER_LIFECYCLE: WeOpsDataPart[] = [
  {
    type: "data-workorder",
    id: "wo_abc123def456gh78",
    data: { ...BASE, status: "DRAFT", timestamp: "2026-02-16T12:00:00.000Z" },
  },
  {
    type: "data-workorder",
    id: "wo_abc123def456gh78",
    data: { ...BASE, status: "IN_REVIEW", timestamp: "2026-02-16T12:00:01.000Z" },
  },
  {
    type: "data-workorder",
    id: "wo_abc123def456gh78",
    data: {
      ...BASE,
      status: "APPROVAL_PENDING",
      timestamp: "2026-02-16T12:00:02.000Z",
      pending_approvals: [{
        type: "governance",
        status: "PENDING",
        required_role: "ADMIN",
        approver_ref: null,
        granted_at: null,
      }],
    },
  },
  {
    type: "data-workorder",
    id: "wo_abc123def456gh78",
    data: { ...BASE, status: "APPROVED", timestamp: "2026-02-16T12:00:03.000Z" },
  },
  {
    type: "data-workorder",
    id: "wo_abc123def456gh78",
    data: { ...BASE, status: "RUNNING", timestamp: "2026-02-16T12:00:04.000Z" },
  },
  {
    type: "data-workorder",
    id: "wo_abc123def456gh78",
    data: { ...BASE, status: "COMPLETED", timestamp: "2026-02-16T12:00:05.000Z" },
  },
];
