// test/fixtures/escalation-event.fixture.ts - EscalationDataPart G1->G2 escalation

import type { EscalationDataPart } from "../../src/stream/data-parts.ts";
import type { WeOpsDataPart } from "../../src/stream/data-parts.ts";

export const G1_TO_G2_ESCALATION: EscalationDataPart = {
  escalation_id: "esc_abc123def456gh78",
  work_order_id: "wo_abc123def456gh78",
  rung: 3,
  rung_name: "Approval",
  trigger: "PHI_DETECTED",
  trigger_detail: "PHI detected in patient discharge summary field",
  required_actions: [
    {
      action_type: "APPROVAL_REQUIRED",
      target_role: "ADMIN",
      description: "Admin must approve PHI access for discharge coordination",
      completed: false,
    },
  ],
  resolved: false,
  resolved_at: null,
  timestamp: "2026-02-16T12:00:02.000Z",
};

export const G1_TO_G2_ESCALATION_DATA_PART: WeOpsDataPart = {
  type: "data-escalation",
  id: "esc_abc123def456gh78",
  data: G1_TO_G2_ESCALATION,
};
