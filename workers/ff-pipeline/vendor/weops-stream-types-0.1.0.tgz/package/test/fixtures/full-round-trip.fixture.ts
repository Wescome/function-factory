// test/fixtures/full-round-trip.fixture.ts - Complete governed interaction round-trip

import type { Envelope, EnvelopeResponse } from "../../src/kernel/envelope.ts";
import type { WeOpsDataPart } from "../../src/stream/data-parts.ts";

/**
 * Full governed interaction sequence:
 * 1. Envelope request comes in
 * 2. Governance evaluates and permits with obligations
 * 3. Work order progresses through lifecycle
 * 4. Execution runs tool invocation
 * 5. Work order completes
 */

export const ROUND_TRIP_ENVELOPE: Envelope = {
  envelope_id: "env_roundtrip00001a",
  correlation_id: "env_roundtrip00001a",
  timestamp: "2026-02-16T12:00:00.000Z",
  source: {
    channel: "web",
    device_class: "desktop",
  },
  session: {
    session_id: "ses_roundtrip00001a",
    identity_id: "usr-001",
    workspace_id: "ws_primary_care",
    active_role: "MEMBER",
  },
  intent: {
    intent_type: "tool.invoke",
    payload: { tool: "ehr.read_patient", patient_id: "PT-12345" },
  },
  constraint_ctx: {
    governance_level: "G2",
    autonomy_tier: "T1",
    risk_tier: "R2",
    purpose: "TREATMENT.CARE_DELIVERY",
    classification: "CONFIDENTIAL",
  },
};

export const ROUND_TRIP_GOVERNANCE: WeOpsDataPart = {
  type: "data-governance",
  data: {
    policy_decision_id: "pd_roundtrip00001a",
    decision: "PERMIT",
    reasons: [
      {
        code: "PURPOSE_VALID",
        severity: "INFO",
        summary: "Purpose matches treatment domain",
        detail: "TREATMENT.CARE_DELIVERY is valid for MEMBER role in primary_care workspace",
        next_steps: null,
      },
    ],
    obligations: [
      { type: "REQUIRE_EVIDENCE_BUNDLE", value: {}, satisfied: false },
    ],
    escalation_rung: null,
    escalation_trigger: null,
    work_order_id: "wo_roundtrip00001a",
    invocation_id: null,
    tool_id: "ehr.read_patient",
    timestamp: "2026-02-16T12:00:00.100Z",
  },
};

export const ROUND_TRIP_WORK_ORDER_APPROVED: WeOpsDataPart = {
  type: "data-workorder",
  id: "wo_roundtrip00001a",
  data: {
    work_order_id: "wo_roundtrip00001a",
    parent_work_order_id: null,
    status: "APPROVED",
    primary_purpose: "TREATMENT.CARE_DELIVERY",
    acting_role: "MEMBER",
    stakeholders: ["usr-001"],
    autonomy_tier: "T1",
    risk_tier: "R2",
    decision_rule_on_conflict: "ESCALATE_WITH_OPTIONS_MEMO",
    compensation_sub_state: null,
    pending_approvals: [],
    timestamp: "2026-02-16T12:00:00.200Z",
  },
};

export const ROUND_TRIP_EXECUTION: WeOpsDataPart = {
  type: "data-execution",
  id: "wo_roundtrip00001a",
  data: {
    work_order_id: "wo_roundtrip00001a",
    plan_hash: "sha256:abc123",
    phase: "COMPLETE",
    current_step_index: 0,
    total_steps: 1,
    steps: [
      {
        step_index: 0,
        tool_id: "ehr.read_patient",
        tool_label: "ehr read_patient",
        status: "COMPLETED",
        invocation_id: "inv_roundtrip00001a",
        started_at: "2026-02-16T12:00:00.300Z",
        completed_at: "2026-02-16T12:00:00.800Z",
        output_summary: "Patient record retrieved successfully",
      },
    ],
    temporal: {
      plan_start_time: "2026-02-16T12:00:00.300Z",
      elapsed_ms: 500,
      estimated_remaining_ms: 0,
      tightest_deadline: null,
      deadline_margin_ms: null,
    },
    compensation_sub_state: null,
    timestamp: "2026-02-16T12:00:00.800Z",
  },
};

export const ROUND_TRIP_WORK_ORDER_COMPLETED: WeOpsDataPart = {
  type: "data-workorder",
  id: "wo_roundtrip00001a",
  data: {
    work_order_id: "wo_roundtrip00001a",
    parent_work_order_id: null,
    status: "COMPLETED",
    primary_purpose: "TREATMENT.CARE_DELIVERY",
    acting_role: "MEMBER",
    stakeholders: ["usr-001"],
    autonomy_tier: "T1",
    risk_tier: "R2",
    decision_rule_on_conflict: "ESCALATE_WITH_OPTIONS_MEMO",
    compensation_sub_state: null,
    pending_approvals: [],
    timestamp: "2026-02-16T12:00:01.000Z",
  },
};

export const ROUND_TRIP_RESPONSE: EnvelopeResponse = {
  envelope_id: "env_roundtrip00001a",
  correlation_id: "env_roundtrip00001a",
  timestamp: "2026-02-16T12:00:01.000Z",
  status: "ok",
  governance_applied: {
    effective_level: "G2",
    pdp_evaluated: true,
    decision: "PERMIT",
    policy_decision_id: "pd_roundtrip00001a",
  },
  result: { patient_id: "PT-12345", status: "retrieved" },
  evidence_refs: ["ev_roundtrip00001a"],
};

/** Complete sequence in order */
export const FULL_ROUND_TRIP_SEQUENCE: WeOpsDataPart[] = [
  ROUND_TRIP_GOVERNANCE,
  ROUND_TRIP_WORK_ORDER_APPROVED,
  ROUND_TRIP_EXECUTION,
  ROUND_TRIP_WORK_ORDER_COMPLETED,
];
