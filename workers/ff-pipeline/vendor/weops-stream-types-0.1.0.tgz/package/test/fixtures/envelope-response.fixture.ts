// test/fixtures/envelope-response.fixture.ts - Valid EnvelopeResponse fixture

import type { EnvelopeResponse } from "../../src/kernel/envelope.ts";

export const VALID_ENVELOPE_RESPONSE: EnvelopeResponse = {
  envelope_id: "env_abc123def456gh78",
  correlation_id: "env_xyz789uvw012ab34",
  timestamp: "2026-02-16T12:00:01.000Z",
  status: "ok",
  governance_applied: {
    effective_level: "G2",
    pdp_evaluated: true,
    decision: "PERMIT",
    policy_decision_id: "pd_abc123def456gh78",
    escalation_id: undefined,
  },
  result: { work_order_id: "wo_abc123def456gh78" },
  evidence_refs: ["ev_abc123def456gh78"],
  obligations: [
    { type: "REQUIRE_EVIDENCE_BUNDLE", severity: "HIGH" },
  ],
  errors: undefined,
};
