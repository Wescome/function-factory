// test/stream/config.test.ts - We-Gradient stream configuration tests
import { describe, test, expect } from "bun:test";

import { default_stream_config } from "../../src/stream/config.ts";
import type { WeGradientStreamConfig } from "../../src/stream/config.ts";

describe("stream/config", () => {
  describe("default_stream_config", () => {
    test("level 0 returns all disabled", () => {
      const config = default_stream_config(0);
      const values = Object.values(config);
      for (const val of values) {
        expect(val).toBe("disabled");
      }
    });

    test("level 1 returns all disabled", () => {
      const config = default_stream_config(1);
      const values = Object.values(config);
      for (const val of values) {
        expect(val).toBe("disabled");
      }
    });

    test("level 5 has no disabled fields", () => {
      const config = default_stream_config(5);
      const values = Object.values(config);
      for (const val of values) {
        expect(val).not.toBe("disabled");
      }
    });

    test("level 2 has workorder as persistent", () => {
      const config = default_stream_config(2);
      expect(config.workorder).toBe("persistent");
    });

    test("level 2 has governance as transient", () => {
      const config = default_stream_config(2);
      expect(config.governance).toBe("transient");
    });

    test("level 2 has execution as persistent-summary", () => {
      const config = default_stream_config(2);
      expect(config.execution).toBe("persistent-summary");
    });

    test("level 2 has planvalidation disabled", () => {
      const config = default_stream_config(2);
      expect(config.planvalidation).toBe("disabled");
    });

    test("level 4 has governance as persistent", () => {
      const config = default_stream_config(4);
      expect(config.governance).toBe("persistent");
    });

    test("level 4 has planvalidation as persistent", () => {
      const config = default_stream_config(4);
      expect(config.planvalidation).toBe("persistent");
    });

    test("level 4 has execution as persistent-full", () => {
      const config = default_stream_config(4);
      expect(config.execution).toBe("persistent-full");
    });

    test("level 4 has drift as transient", () => {
      const config = default_stream_config(4);
      expect(config.drift).toBe("transient");
    });

    test("level 4 has evidence as persistent-all", () => {
      const config = default_stream_config(4);
      expect(config.evidence).toBe("persistent-all");
    });
  });

  describe("boundary clamping", () => {
    test("negative level clamps to 0", () => {
      const config = default_stream_config(-1);
      const level0 = default_stream_config(0);
      expect(config).toEqual(level0);
    });

    test("level > 5 clamps to 5", () => {
      const config = default_stream_config(99);
      const level5 = default_stream_config(5);
      expect(config).toEqual(level5);
    });

    test("fractional level is floored", () => {
      const config = default_stream_config(2.9);
      const level2 = default_stream_config(2);
      expect(config).toEqual(level2);
    });
  });

  describe("config has all 8 data part keys", () => {
    test("level 0 config shape has all keys", () => {
      const config = default_stream_config(0);
      const expected_keys = [
        "workorder",
        "governance",
        "planvalidation",
        "execution",
        "escalation",
        "reasoning",
        "drift",
        "evidence",
      ];
      for (const key of expected_keys) {
        expect(config).toHaveProperty(key);
      }
    });
  });
});
