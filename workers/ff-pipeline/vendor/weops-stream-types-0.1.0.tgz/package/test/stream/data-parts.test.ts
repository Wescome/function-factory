// test/stream/data-parts.test.ts - Data part type discriminator field tests
import { describe, test, expect } from "bun:test";

import type {
  WeOpsDataPart,
  WorkOrderDataPart,
  GovernanceDataPart,
  PlanValidationDataPart,
  ExecutionDataPart,
  EscalationDataPart,
  ReasoningDataPart,
  DriftDataPart,
  DecisionLifecycleDataPart,
  ModelResolutionDataPart,
} from "../../src/stream/data-parts.ts";
import { WORK_ORDER_LIFECYCLE } from "../fixtures/work-order-stream.fixture.ts";
import { GOVERNANCE_PERMIT_DATA_PART } from "../fixtures/governance-decision.fixture.ts";
import { G1_TO_G2_ESCALATION_DATA_PART } from "../fixtures/escalation-event.fixture.ts";

describe("stream/data-parts", () => {
  describe("type discriminator fields", () => {
    test("WorkOrderDataPart uses type 'data-workorder'", () => {
      const part = WORK_ORDER_LIFECYCLE[0]!;
      expect(part.type).toBe("data-workorder");
    });

    test("GovernanceDataPart uses type 'data-governance'", () => {
      expect(GOVERNANCE_PERMIT_DATA_PART.type).toBe("data-governance");
    });

    test("EscalationDataPart uses type 'data-escalation'", () => {
      expect(G1_TO_G2_ESCALATION_DATA_PART.type).toBe("data-escalation");
    });

    test("all data part type discriminators are valid strings", () => {
      const expected_types = [
        "data-workorder",
        "data-governance",
        "data-planvalidation",
        "data-execution",
        "data-escalation",
        "data-reasoning",
        "data-drift",
        "data-decision-lifecycle",
        "data-model-resolution",
      ] as const;

      // Build one of each data part type to verify structure
      const parts: WeOpsDataPart[] = [
        {
          type: "data-workorder",
          id: "wo_test1234567890ab",
          data: WORK_ORDER_LIFECYCLE[0]!.data as WorkOrderDataPart,
        },
        GOVERNANCE_PERMIT_DATA_PART,
        {
          type: "data-planvalidation",
          id: "pvr_test",
          data: {
            pvr_id: "pvr_test",
            work_order_id: "wo_test1234567890ab",
            plan_hash: "sha256:abc",
            result: "VALID",
            dimensions: [],
            compliance_certificate: null,
            re_planning_attempt: 0,
            timestamp: "2026-02-16T12:00:00.000Z",
          },
        },
        {
          type: "data-execution",
          id: "wo_test1234567890ab",
          data: {
            work_order_id: "wo_test1234567890ab",
            plan_hash: "sha256:abc",
            phase: "EXECUTING",
            current_step_index: 0,
            total_steps: 1,
            steps: [],
            temporal: {
              plan_start_time: "2026-02-16T12:00:00.000Z",
              elapsed_ms: 100,
              estimated_remaining_ms: 0,
              tightest_deadline: null,
              deadline_margin_ms: null,
            },
            compensation_sub_state: null,
            timestamp: "2026-02-16T12:00:00.000Z",
          },
        },
        G1_TO_G2_ESCALATION_DATA_PART,
        {
          type: "data-reasoning",
          id: "trace_test",
          data: {
            trace_id: "trace_test",
            work_order_id: "wo_test1234567890ab",
            granularity: "STRUCTURED",
            tools_considered: [],
            constraints_referenced: [],
            plan_justification: "test justification",
            confidence_signals: {},
            timestamp: "2026-02-16T12:00:00.000Z",
          },
        },
        {
          type: "data-drift",
          data: {
            alert_id: "alert_test",
            signal_category: "POLICY",
            metric: "test_metric",
            current_value: 10,
            baseline_value: 5,
            threshold: 3,
            severity: "WARNING",
            contributing_invocations: [],
            automated_response: null,
            timestamp: "2026-02-16T12:00:00.000Z",
          },
          transient: true,
        },
        {
          type: "data-decision-lifecycle",
          id: "d4f8a001-0001-4000-a000-000000000001",
          data: {
            decision_id: "d4f8a001-0001-4000-a000-000000000001",
            intent: "Approve patient discharge from post-operative care",
            stratum: "operational",
            domain: "clinical",
            urgency: "standard",
            status: "resolved",
            authority: { type: "role", identifier: "attending_physician" },
            delegated_from: null,
            constraints: [
              {
                type: "policy",
                description: "24-hour post-operative observation",
                enforcement: "hard",
                passed: true,
              },
            ],
            facts_count: 3,
            preconditions_met: true,
            deadline: "2026-02-20T18:00:00Z",
            sub_decisions: [],
            outcome: {
              value: "approved",
              rationale: "All discharge criteria met",
              effects: ["Generate discharge summary", "Schedule follow-up"],
            },
            confidence: 0.92,
            resolved_by: { type: "agent", identifier: "discharge_coordinator" },
            resolved_at: "2026-02-20T11:30:00Z",
            audit_level: "full",
            parent_decision_id: null,
            work_order_id: "wo_discharge_001",
            timestamp: "2026-02-20T11:30:00Z",
          },
        },
        {
          type: "data-model-resolution",
          id: "mrr_test123",
          data: {
            resolution_id: "mrr_test123",
            work_order_id: "wo_test1234567890ab",
            provider_id: "openrouter/anthropic/claude-3-5-haiku",
            model_id: "claude-3-5-haiku-20241022",
            binding_basis: "POLICY_RESOLVED",
            resolution_score: 70,
            cost_tier: "economy",
            latency_tier: "standard",
            eliminated_count: 2,
            total_considered: 4,
            compliance_matched: ["HIPAA_BAA", "SOC2_TYPE2"],
            elimination_log: [
              {
                provider_id: "openrouter/openai/gpt-4o",
                eliminated_at_phase: "compliance",
                reason: "MISSING_CERTIFICATION",
                detail: "Required: HIPAA_BAA. Provider holds: SOC2_TYPE2, GDPR.",
              },
            ],
            scoring_log: [
              { provider_id: "openrouter/anthropic/claude-3-5-haiku", score: 70 },
              { provider_id: "openrouter/anthropic/claude-3-5-sonnet", score: 45 },
            ],
            resolved: true,
            failure_reason: null,
            timestamp: "2026-02-16T12:00:00.000Z",
          },
        },
      ];

      for (let i = 0; i < parts.length; i++) {
        expect(parts[i]!.type).toBe(expected_types[i]!);
      }
    });
  });

  describe("WorkOrderDataPart fixture structure", () => {
    test("lifecycle fixture has 6 entries (DRAFT through COMPLETED)", () => {
      expect(WORK_ORDER_LIFECYCLE.length).toBe(6);
    });

    test("lifecycle follows valid status progression", () => {
      const expected_statuses = [
        "DRAFT",
        "IN_REVIEW",
        "APPROVAL_PENDING",
        "APPROVED",
        "RUNNING",
        "COMPLETED",
      ] as const;
      for (let i = 0; i < WORK_ORDER_LIFECYCLE.length; i++) {
        const part = WORK_ORDER_LIFECYCLE[i]!;
        if (part.type === "data-workorder") {
          expect(part.data.status).toBe(expected_statuses[i]!);
        }
      }
    });
  });

  describe("GovernanceDataPart fixture structure", () => {
    test("PERMIT decision has reasons array", () => {
      if (GOVERNANCE_PERMIT_DATA_PART.type === "data-governance") {
        expect(GOVERNANCE_PERMIT_DATA_PART.data.reasons.length).toBeGreaterThan(0);
      }
    });

    test("PERMIT decision has obligations array", () => {
      if (GOVERNANCE_PERMIT_DATA_PART.type === "data-governance") {
        expect(GOVERNANCE_PERMIT_DATA_PART.data.obligations.length).toBeGreaterThan(0);
      }
    });
  });

  describe("EscalationDataPart fixture structure", () => {
    test("escalation has rung and rung_name", () => {
      if (G1_TO_G2_ESCALATION_DATA_PART.type === "data-escalation") {
        expect(G1_TO_G2_ESCALATION_DATA_PART.data.rung).toBe(3);
        expect(G1_TO_G2_ESCALATION_DATA_PART.data.rung_name).toBe("Approval");
      }
    });

    test("escalation has trigger type", () => {
      if (G1_TO_G2_ESCALATION_DATA_PART.type === "data-escalation") {
        expect(G1_TO_G2_ESCALATION_DATA_PART.data.trigger).toBe("PHI_DETECTED");
      }
    });
  });
});
