// test/kernel/commonground.test.ts - Common Ground assembly tests
import { describe, test, expect } from "bun:test";

import {
  CG_ASSEMBLY_ID,
  CG_ASSEMBLY_VERSION,
  CG_KERNEL_MIN_VERSION,
  CG_GOVERNANCE_TIER_VALUES,
  WORKSPACE_STATUS_VALUES,
  WORKSPACE_TRANSITIONS,
  validate_workspace_transition,
  TEAM_ROLE_VALUES,
  BO_STATUS_VALUES,
  CG_CLASSIFICATION_VALUES,
  MEMORY_LANE_VALUES,
  ESCALATION_RUNG_VALUES,
  RISK_TO_RUNG_MAPPING,
  assign_escalation_rung,
  CONFLICT_STATUS_VALUES,
  CG_PURPOSE_VALUES,
  CG_TAXONOMY,
  validate_cg_purpose,
  list_cg_trunks,
  list_cg_branches,
  list_cg_leaves,
  get_cg_description,
  CG_ASSEMBLY_MANIFEST,
} from "../../src/kernel/commonground.ts";
import type {
  CGPurpose,
  CGWorkspace,
  ConflictRecord,
  ModuleManifest,
  EscalationRung,
} from "../../src/kernel/commonground.ts";

// ---------------------------------------------------------------------------
// Assembly identity
// ---------------------------------------------------------------------------
describe("kernel/commonground", () => {
  describe("assembly identity", () => {
    test("assembly ID is common-ground", () => {
      expect(CG_ASSEMBLY_ID).toBe("common-ground");
    });

    test("assembly version is 1.0.0", () => {
      expect(CG_ASSEMBLY_VERSION).toBe("1.0.0");
    });

    test("kernel min version is 1.3.1", () => {
      expect(CG_KERNEL_MIN_VERSION).toBe("1.3.1");
    });
  });

  // ---------------------------------------------------------------------------
  // Governance tiers
  // ---------------------------------------------------------------------------
  describe("governance tiers", () => {
    test("exactly 2 tiers: G1, G2", () => {
      expect(CG_GOVERNANCE_TIER_VALUES).toEqual(["G1", "G2"]);
    });
  });

  // ---------------------------------------------------------------------------
  // Workspace status + transitions
  // ---------------------------------------------------------------------------
  describe("workspace status", () => {
    test("4 workspace statuses", () => {
      expect(WORKSPACE_STATUS_VALUES.length).toBe(4);
    });

    test("valid transitions: PROVISIONING -> ACTIVE", () => {
      expect(validate_workspace_transition("PROVISIONING", "ACTIVE")).toBe(true);
    });

    test("valid transitions: ACTIVE -> SUSPENDED", () => {
      expect(validate_workspace_transition("ACTIVE", "SUSPENDED")).toBe(true);
    });

    test("valid transitions: ACTIVE -> ARCHIVED", () => {
      expect(validate_workspace_transition("ACTIVE", "ARCHIVED")).toBe(true);
    });

    test("valid transitions: SUSPENDED -> ACTIVE", () => {
      expect(validate_workspace_transition("SUSPENDED", "ACTIVE")).toBe(true);
    });

    test("valid transitions: SUSPENDED -> ARCHIVED", () => {
      expect(validate_workspace_transition("SUSPENDED", "ARCHIVED")).toBe(true);
    });

    test("invalid: PROVISIONING -> SUSPENDED", () => {
      expect(validate_workspace_transition("PROVISIONING", "SUSPENDED")).toBe(false);
    });

    test("invalid: ARCHIVED -> anything", () => {
      expect(validate_workspace_transition("ARCHIVED", "ACTIVE")).toBe(false);
    });

    test("invalid: unknown status", () => {
      expect(validate_workspace_transition("INVALID", "ACTIVE")).toBe(false);
    });
  });

  // ---------------------------------------------------------------------------
  // Team roles
  // ---------------------------------------------------------------------------
  describe("team roles", () => {
    test("exactly 3 roles: OWNER, PARTICIPANT, OBSERVER", () => {
      expect(TEAM_ROLE_VALUES).toEqual(["OWNER", "PARTICIPANT", "OBSERVER"]);
    });
  });

  // ---------------------------------------------------------------------------
  // Boundary object status
  // ---------------------------------------------------------------------------
  describe("boundary object status", () => {
    test("4 statuses", () => {
      expect(BO_STATUS_VALUES.length).toBe(4);
      expect(BO_STATUS_VALUES).toContain("DRAFT");
      expect(BO_STATUS_VALUES).toContain("UNDER_REVIEW");
      expect(BO_STATUS_VALUES).toContain("APPROVED");
      expect(BO_STATUS_VALUES).toContain("SUPERSEDED");
    });
  });

  // ---------------------------------------------------------------------------
  // 3-lane memory
  // ---------------------------------------------------------------------------
  describe("memory lanes", () => {
    test("exactly 3 lanes", () => {
      expect(MEMORY_LANE_VALUES).toEqual(["COMMON_GROUND", "TEAM_SCOPED", "EVIDENCE"]);
    });
  });

  // ---------------------------------------------------------------------------
  // Escalation rungs + risk mapping
  // ---------------------------------------------------------------------------
  describe("escalation rungs", () => {
    test("4 rungs", () => {
      expect(ESCALATION_RUNG_VALUES.length).toBe(4);
    });

    test("R0 -> RUNG_1 (request clarification)", () => {
      expect(assign_escalation_rung("R0")).toBe("RUNG_1");
    });

    test("R1 -> RUNG_2 (require Decision Memo)", () => {
      expect(assign_escalation_rung("R1")).toBe("RUNG_2");
    });

    test("R2 -> RUNG_3 (route to governance authority)", () => {
      expect(assign_escalation_rung("R2")).toBe("RUNG_3");
    });

    test("R3 -> RUNG_0 (auto-deny)", () => {
      expect(assign_escalation_rung("R3")).toBe("RUNG_0");
    });

    test("invalid risk tier returns undefined", () => {
      expect(assign_escalation_rung("R99")).toBeUndefined();
    });
  });

  // ---------------------------------------------------------------------------
  // Conflict status
  // ---------------------------------------------------------------------------
  describe("conflict status", () => {
    test("4 conflict statuses", () => {
      expect(CONFLICT_STATUS_VALUES).toEqual(["OPEN", "ESCALATED", "RESOLVED", "DENIED"]);
    });
  });

  // ---------------------------------------------------------------------------
  // Purpose taxonomy — 27 leaves, 3-level
  // ---------------------------------------------------------------------------
  describe("purpose taxonomy", () => {
    test("exactly 27 leaf purposes", () => {
      expect(CG_PURPOSE_VALUES.length).toBe(27);
    });

    test("all 27 purposes validate", () => {
      for (const p of CG_PURPOSE_VALUES) {
        expect(validate_cg_purpose(p)).toBe(true);
      }
    });

    test("all purposes are 3-level (TRUNK.BRANCH.LEAF)", () => {
      for (const p of CG_PURPOSE_VALUES) {
        expect(p.split(".").length).toBe(3);
      }
    });

    test("rejects 2-level purpose", () => {
      expect(validate_cg_purpose("COORD.PM")).toBe(false);
    });

    test("rejects trunk-only", () => {
      expect(validate_cg_purpose("COORD")).toBe(false);
    });

    test("rejects invalid purpose", () => {
      expect(validate_cg_purpose("FAKE.THING.NOTHING")).toBe(false);
    });

    test("rejects empty string", () => {
      expect(validate_cg_purpose("")).toBe(false);
    });

    test("3 trunks: COORD, OPS, ANLYS", () => {
      const trunks = list_cg_trunks();
      expect(trunks.length).toBe(3);
      expect(trunks).toContain("COORD");
      expect(trunks).toContain("OPS");
      expect(trunks).toContain("ANLYS");
    });

    test("COORD has 4 branches: PM, DEC, KM, COMP", () => {
      const branches = list_cg_branches("COORD");
      expect(branches).not.toBeUndefined();
      expect(branches!.length).toBe(4);
      expect(branches).toContain("PM");
      expect(branches).toContain("DEC");
      expect(branches).toContain("KM");
      expect(branches).toContain("COMP");
    });

    test("OPS has 3 branches: INC, ONB, RPT", () => {
      const branches = list_cg_branches("OPS");
      expect(branches).not.toBeUndefined();
      expect(branches!.length).toBe(3);
    });

    test("ANLYS has 2 branches: ASMT, PLN", () => {
      const branches = list_cg_branches("ANLYS");
      expect(branches).not.toBeUndefined();
      expect(branches!.length).toBe(2);
    });

    test("unknown trunk returns undefined", () => {
      expect(list_cg_branches("FAKE")).toBeUndefined();
    });

    test("COORD.PM has 3 leaves", () => {
      const leaves = list_cg_leaves("COORD", "PM");
      expect(leaves).not.toBeUndefined();
      expect(leaves!.length).toBe(3);
      expect(leaves).toContain("STATUS_REVIEW");
      expect(leaves).toContain("MILESTONE_PLANNING");
      expect(leaves).toContain("RISK_TRACKING");
    });

    test("unknown branch returns undefined", () => {
      expect(list_cg_leaves("COORD", "FAKE")).toBeUndefined();
    });

    test("get_cg_description returns description for valid purpose", () => {
      const desc = get_cg_description("COORD.PM.STATUS_REVIEW");
      expect(desc).toBe("Project status review and reporting");
    });

    test("get_cg_description returns undefined for invalid purpose", () => {
      expect(get_cg_description("FAKE.THING.NOTHING")).toBeUndefined();
    });

    test("get_cg_description returns undefined for 2-level string", () => {
      expect(get_cg_description("COORD.PM")).toBeUndefined();
    });

    test("taxonomy leaf count matches purpose values count", () => {
      let total = 0;
      for (const trunk of Object.keys(CG_TAXONOMY)) {
        for (const branch of Object.keys(CG_TAXONOMY[trunk]!)) {
          total += Object.keys(CG_TAXONOMY[trunk]![branch]!).length;
        }
      }
      expect(total).toBe(27);
    });

    test("COORD has 12 leaves (4 branches x 3)", () => {
      let count = 0;
      for (const branch of Object.keys(CG_TAXONOMY["COORD"]!)) {
        count += Object.keys(CG_TAXONOMY["COORD"]![branch]!).length;
      }
      expect(count).toBe(12);
    });

    test("OPS has 9 leaves (3 branches x 3)", () => {
      let count = 0;
      for (const branch of Object.keys(CG_TAXONOMY["OPS"]!)) {
        count += Object.keys(CG_TAXONOMY["OPS"]![branch]!).length;
      }
      expect(count).toBe(9);
    });

    test("ANLYS has 6 leaves (2 branches x 3)", () => {
      let count = 0;
      for (const branch of Object.keys(CG_TAXONOMY["ANLYS"]!)) {
        count += Object.keys(CG_TAXONOMY["ANLYS"]![branch]!).length;
      }
      expect(count).toBe(6);
    });
  });

  // ---------------------------------------------------------------------------
  // Assembly manifest — 8 AOMA modules
  // ---------------------------------------------------------------------------
  describe("assembly manifest", () => {
    test("exactly 8 modules", () => {
      expect(CG_ASSEMBLY_MANIFEST.length).toBe(8);
    });

    test("all modules have required fields", () => {
      for (const m of CG_ASSEMBLY_MANIFEST) {
        expect(m.module_id).toBeTruthy();
        expect(m.responsibility).toBeTruthy();
        expect(m.tools.length).toBeGreaterThan(0);
        expect(m.compensation_strategy).toBeTruthy();
      }
    });

    test("module IDs are prefixed with cg-", () => {
      for (const m of CG_ASSEMBLY_MANIFEST) {
        expect(m.module_id.startsWith("cg-")).toBe(true);
      }
    });

    test("expected module IDs present", () => {
      const ids = CG_ASSEMBLY_MANIFEST.map((m) => m.module_id);
      expect(ids).toContain("cg-workspace-mgr");
      expect(ids).toContain("cg-team-enrollment");
      expect(ids).toContain("cg-boundary-obj-mgr");
      expect(ids).toContain("cg-conflict-detector");
      expect(ids).toContain("cg-escalation-engine");
      expect(ids).toContain("cg-memory-lane-mgr");
      expect(ids).toContain("cg-purpose-binder");
      expect(ids).toContain("cg-evidence-collector");
    });

    test("every module has a compensation strategy", () => {
      for (const m of CG_ASSEMBLY_MANIFEST) {
        expect(m.compensation_strategy.length).toBeGreaterThan(0);
      }
    });
  });

  // ---------------------------------------------------------------------------
  // Type shape validation (compile-time + structural)
  // ---------------------------------------------------------------------------
  describe("type shapes", () => {
    test("CGWorkspace satisfies shape", () => {
      const ws: CGWorkspace = {
        workspace_id: "ws_test_001",
        display_name: "Test Workspace",
        primary_purpose: "COORD.PM.STATUS_REVIEW",
        governance_tier: "G1",
        status: "PROVISIONING",
        owner_team: "team-alpha",
        enrolled_teams: [],
        purpose_taxonomy_version: "1.0.0",
        created_at: "2026-02-21T00:00:00Z",
        updated_at: "2026-02-21T00:00:00Z",
      };
      expect(ws.workspace_id).toBeTruthy();
      expect(ws.enrolled_teams.length).toBe(0);
    });

    test("ConflictRecord satisfies shape", () => {
      const cr: ConflictRecord = {
        collision_id: "evt_test_001",
        work_order_id: "wo_test_001",
        detection_timestamp: "2026-02-21T00:00:00Z",
        conflicting_constraints: [
          {
            constraint_id: "c1",
            issuing_team: "team-a",
            policy_bundle_ref: "bo_pb_001",
            human_readable_text: "Must have dual approval",
            affected_action_classes: ["tool.invoke"],
          },
          {
            constraint_id: "c2",
            issuing_team: "team-b",
            policy_bundle_ref: "bo_pb_002",
            human_readable_text: "Single approval sufficient",
            affected_action_classes: ["tool.invoke"],
          },
        ],
        escalation_rung: "RUNG_2",
        status: "OPEN",
        evidence_ref: "ev_test_001",
      };
      expect(cr.conflicting_constraints.length).toBe(2);
      expect(cr.escalation_rung).toBe("RUNG_2");
    });
  });
});
