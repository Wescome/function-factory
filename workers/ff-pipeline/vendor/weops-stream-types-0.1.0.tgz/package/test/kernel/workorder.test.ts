// test/kernel/workorder.test.ts - Work order state machine and validation tests
import { describe, test, expect } from "bun:test";

import { ALLOWED_TRANSITIONS } from "../../src/kernel/workorder.ts";
import type { WorkOrder } from "../../src/kernel/workorder.ts";
import { validate_work_order, validate_transition } from "../../src/validators/workorder.ts";
import type { WorkOrderStatus } from "../../src/kernel/enums.ts";

// ---------------------------------------------------------------------------
// Minimal valid WorkOrder fixture for validation tests
// ---------------------------------------------------------------------------
const VALID_WORK_ORDER: WorkOrder = {
  work_order_id: "wo_abc123def456gh78",
  workspace_id: "ws_primary_care",
  schema_version: "1.0.0",
  version: "1",
  primary_purpose: "TREATMENT.CARE_COORDINATION",
  acting_role: "MEMBER",
  stakeholders: ["usr-001"],
  autonomy_tier: "T1",
  risk_tier: "R2",
  status: "DRAFT",
};

describe("kernel/workorder", () => {
  describe("ALLOWED_TRANSITIONS", () => {
    test("DRAFT can transition to IN_REVIEW", () => {
      expect(ALLOWED_TRANSITIONS["DRAFT"]).toContain("IN_REVIEW");
    });

    test("IN_REVIEW can transition to APPROVAL_PENDING", () => {
      expect(ALLOWED_TRANSITIONS["IN_REVIEW"]).toContain("APPROVAL_PENDING");
    });

    test("IN_REVIEW can transition back to DRAFT", () => {
      expect(ALLOWED_TRANSITIONS["IN_REVIEW"]).toContain("DRAFT");
    });

    test("APPROVAL_PENDING can transition to APPROVED", () => {
      expect(ALLOWED_TRANSITIONS["APPROVAL_PENDING"]).toContain("APPROVED");
    });

    test("APPROVED can transition to RUNNING", () => {
      expect(ALLOWED_TRANSITIONS["APPROVED"]).toContain("RUNNING");
    });

    test("RUNNING can transition to COMPLETED", () => {
      expect(ALLOWED_TRANSITIONS["RUNNING"]).toContain("COMPLETED");
    });

    test("RUNNING can transition to FAILED", () => {
      expect(ALLOWED_TRANSITIONS["RUNNING"]).toContain("FAILED");
    });

    test("FAILED can transition to COMPENSATING", () => {
      expect(ALLOWED_TRANSITIONS["FAILED"]).toContain("COMPENSATING");
    });

    test("COMPLETED is a terminal state (no transitions)", () => {
      expect(ALLOWED_TRANSITIONS["COMPLETED"]).toEqual([]);
    });

    test("FAILED_FINAL is a terminal state (no transitions)", () => {
      expect(ALLOWED_TRANSITIONS["FAILED_FINAL"]).toEqual([]);
    });
  });

  describe("validate_transition", () => {
    test("valid transitions return null", () => {
      const valid_transitions: [WorkOrderStatus, WorkOrderStatus][] = [
        ["DRAFT", "IN_REVIEW"],
        ["IN_REVIEW", "APPROVAL_PENDING"],
        ["IN_REVIEW", "DRAFT"],
        ["APPROVAL_PENDING", "APPROVED"],
        ["APPROVAL_PENDING", "IN_REVIEW"],
        ["APPROVED", "RUNNING"],
        ["RUNNING", "COMPLETED"],
        ["RUNNING", "FAILED"],
        ["FAILED", "COMPENSATING"],
        ["FAILED", "FAILED_FINAL"],
        ["COMPENSATING", "FAILED_FINAL"],
        ["COMPENSATING", "COMPLETED"],
      ];

      for (const [from, to] of valid_transitions) {
        expect(validate_transition(from, to)).toBeNull();
      }
    });

    test("invalid transition DRAFT -> COMPLETED returns error", () => {
      const result = validate_transition("DRAFT", "COMPLETED");
      expect(result).not.toBeNull();
      expect(result).toContain("not allowed");
    });

    test("invalid transition COMPLETED -> DRAFT returns error", () => {
      const result = validate_transition("COMPLETED", "DRAFT");
      expect(result).not.toBeNull();
      expect(result).toContain("not allowed");
    });

    test("invalid transition DRAFT -> RUNNING returns error", () => {
      const result = validate_transition("DRAFT", "RUNNING");
      expect(result).not.toBeNull();
    });

    test("invalid transition APPROVED -> COMPLETED returns error", () => {
      const result = validate_transition("APPROVED", "COMPLETED");
      expect(result).not.toBeNull();
    });
  });

  describe("validate_work_order", () => {
    test("valid work order returns zero errors", () => {
      const errors = validate_work_order(VALID_WORK_ORDER);
      expect(errors).toEqual([]);
    });

    test("missing work_order_id is caught", () => {
      const bad = { ...VALID_WORK_ORDER, work_order_id: "" } as WorkOrder;
      const errors = validate_work_order(bad);
      expect(errors.some((e) => e.includes("work_order_id"))).toBe(true);
    });

    test("missing workspace_id is caught", () => {
      const bad = { ...VALID_WORK_ORDER, workspace_id: "" } as WorkOrder;
      const errors = validate_work_order(bad);
      expect(errors.some((e) => e.includes("workspace_id"))).toBe(true);
    });

    test("invalid status is caught", () => {
      const bad = { ...VALID_WORK_ORDER, status: "INVALID" as any } as WorkOrder;
      const errors = validate_work_order(bad);
      expect(errors.some((e) => e.includes("status"))).toBe(true);
    });

    test("invalid autonomy_tier is caught", () => {
      const bad = { ...VALID_WORK_ORDER, autonomy_tier: "T9" as any } as WorkOrder;
      const errors = validate_work_order(bad);
      expect(errors.some((e) => e.includes("autonomy_tier"))).toBe(true);
    });

    test("invalid risk_tier is caught", () => {
      const bad = { ...VALID_WORK_ORDER, risk_tier: "R9" as any } as WorkOrder;
      const errors = validate_work_order(bad);
      expect(errors.some((e) => e.includes("risk_tier"))).toBe(true);
    });

    test("missing primary_purpose is caught", () => {
      const bad = { ...VALID_WORK_ORDER, primary_purpose: "" as any } as WorkOrder;
      const errors = validate_work_order(bad);
      expect(errors.some((e) => e.includes("primary_purpose"))).toBe(true);
    });

    test("invalid primary_purpose is caught", () => {
      const bad = { ...VALID_WORK_ORDER, primary_purpose: "INVALID.PURPOSE" as any } as WorkOrder;
      const errors = validate_work_order(bad);
      expect(errors.some((e) => e.includes("primary_purpose"))).toBe(true);
    });

    test("missing acting_role is caught", () => {
      const bad = { ...VALID_WORK_ORDER, acting_role: "" } as WorkOrder;
      const errors = validate_work_order(bad);
      expect(errors.some((e) => e.includes("acting_role"))).toBe(true);
    });
  });
});
