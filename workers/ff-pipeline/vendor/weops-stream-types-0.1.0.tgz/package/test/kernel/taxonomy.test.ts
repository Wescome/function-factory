// test/kernel/taxonomy.test.ts - Purpose taxonomy validation and query tests
import { describe, test, expect } from "bun:test";

import {
  validate_purpose,
  list_domains,
  list_actions,
  get_description,
  TAXONOMY,
} from "../../src/kernel/taxonomy.ts";
import type { Purpose } from "../../src/kernel/taxonomy.ts";

// ---------------------------------------------------------------------------
// All 25 valid purposes (exhaustive from source)
// ---------------------------------------------------------------------------
const ALL_PURPOSES: Purpose[] = [
  "TREATMENT.CARE_COORDINATION",
  "TREATMENT.DISCHARGE_COORDINATION",
  "TREATMENT.CARE_DELIVERY",
  "TREATMENT.CLINICAL_TASKING",
  "TREATMENT.CONSULTATION",
  "PAYMENT.CLAIMS_SUBMISSION",
  "PAYMENT.CLAIMS_ADJUDICATION",
  "PAYMENT.BILLING",
  "PAYMENT.CODING_REVIEW",
  "PAYMENT.DENIAL_MANAGEMENT",
  "PAYMENT.PRIOR_AUTH",
  "OPERATIONS.VENDOR_ONBOARDING",
  "OPERATIONS.WORKFORCE_MANAGEMENT",
  "OPERATIONS.QUALITY_REPORTING",
  "OPERATIONS.QUALITY_SAFETY",
  "OPERATIONS.UTILIZATION_MANAGEMENT",
  "OPERATIONS.SECURITY_ADMIN",
  "LEGAL.DISCLOSURE_REVIEW",
  "LEGAL.CONTRACT_REVIEW",
  "LEGAL.INCIDENT_RESPONSE",
  "LEGAL.CONTRACT_INTERPRETATION",
  "LEGAL.LITIGATION_HOLD",
  "LEGAL.DEFENSE_SUPPORT",
  "PROCUREMENT.VENDOR_ONBOARDING",
  "PROCUREMENT.PURCHASE_APPROVAL",
];

describe("kernel/taxonomy", () => {
  describe("validate_purpose", () => {
    test("all 25 purposes validate successfully", () => {
      for (const purpose of ALL_PURPOSES) {
        expect(validate_purpose(purpose)).toBe(true);
      }
    });

    test("there are exactly 25 purposes", () => {
      expect(ALL_PURPOSES.length).toBe(25);
    });

    test("rejects invalid purpose with bad domain", () => {
      expect(validate_purpose("INVALID.SOMETHING")).toBe(false);
    });

    test("rejects invalid purpose with bad action", () => {
      expect(validate_purpose("TREATMENT.NONEXISTENT")).toBe(false);
    });

    test("rejects empty string", () => {
      expect(validate_purpose("")).toBe(false);
    });

    test("rejects string with no dot", () => {
      expect(validate_purpose("TREATMENT_CARE_COORDINATION")).toBe(false);
    });

    test("rejects string with too many dots", () => {
      expect(validate_purpose("TREATMENT.CARE.EXTRA")).toBe(false);
    });
  });

  describe("list_domains", () => {
    test("returns exactly 5 domains", () => {
      const domains = list_domains();
      expect(domains.length).toBe(5);
    });

    test("contains all expected domains", () => {
      const domains = list_domains();
      expect(domains).toContain("TREATMENT");
      expect(domains).toContain("PAYMENT");
      expect(domains).toContain("OPERATIONS");
      expect(domains).toContain("LEGAL");
      expect(domains).toContain("PROCUREMENT");
    });
  });

  describe("list_actions", () => {
    test("TREATMENT has 5 actions", () => {
      const actions = list_actions("TREATMENT");
      expect(actions).not.toBeUndefined();
      expect(actions!.length).toBe(5);
    });

    test("PAYMENT has 6 actions", () => {
      const actions = list_actions("PAYMENT");
      expect(actions).not.toBeUndefined();
      expect(actions!.length).toBe(6);
    });

    test("OPERATIONS has 6 actions", () => {
      const actions = list_actions("OPERATIONS");
      expect(actions).not.toBeUndefined();
      expect(actions!.length).toBe(6);
    });

    test("LEGAL has 6 actions", () => {
      const actions = list_actions("LEGAL");
      expect(actions).not.toBeUndefined();
      expect(actions!.length).toBe(6);
    });

    test("PROCUREMENT has 2 actions", () => {
      const actions = list_actions("PROCUREMENT");
      expect(actions).not.toBeUndefined();
      expect(actions!.length).toBe(2);
    });

    test("unknown domain returns undefined", () => {
      expect(list_actions("NONEXISTENT")).toBeUndefined();
    });
  });

  describe("get_description", () => {
    test("returns description for valid purpose", () => {
      const desc = get_description("TREATMENT.CARE_COORDINATION");
      expect(desc).toBe("Coordinating patient care across providers");
    });

    test("returns undefined for invalid purpose", () => {
      expect(get_description("FAKE.NOTHING")).toBeUndefined();
    });

    test("returns undefined for malformed string", () => {
      expect(get_description("no-dot")).toBeUndefined();
    });
  });

  describe("TAXONOMY structure", () => {
    test("total purpose count across all domains sums to 25", () => {
      let total = 0;
      for (const domain of Object.keys(TAXONOMY)) {
        const actions = TAXONOMY[domain];
        if (actions) total += Object.keys(actions).length;
      }
      expect(total).toBe(25);
    });
  });
});
