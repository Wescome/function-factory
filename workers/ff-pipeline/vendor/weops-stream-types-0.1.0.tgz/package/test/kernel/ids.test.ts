// test/kernel/ids.test.ts - ID generation, pattern matching, and validation tests
import { describe, test, expect } from "bun:test";

import {
  // generators
  new_work_order_id,
  new_policy_decision_id,
  new_invocation_id,
  new_evidence_id,
  new_workspace_id,
  new_template_id,
  new_assembly_id,
  new_escalation_id,
  new_event_id,
  new_bridge_request_id,
  new_message_id,
  new_boundary_object_id,
  new_envelope_id,
  new_session_id,
  // patterns
  WORK_ORDER_ID_PATTERN,
  POLICY_DECISION_ID_PATTERN,
  INVOCATION_ID_PATTERN,
  EVIDENCE_ID_PATTERN,
  WORKSPACE_ID_PATTERN,
  TEMPLATE_ID_PATTERN,
  ASSEMBLY_ID_PATTERN,
  ESCALATION_ID_PATTERN,
  EVENT_ID_PATTERN,
  BRIDGE_REQUEST_ID_PATTERN,
  MESSAGE_ID_PATTERN,
  BOUNDARY_OBJECT_ID_PATTERN,
  ENVELOPE_ID_PATTERN,
  SESSION_ID_PATTERN,
  // validators
  is_valid_work_order_id,
  is_valid_policy_decision_id,
  is_valid_invocation_id,
  is_valid_evidence_id,
  is_valid_workspace_id,
  is_valid_template_id,
  is_valid_assembly_id,
  is_valid_escalation_id,
  is_valid_event_id,
  is_valid_bridge_request_id,
  is_valid_message_id,
  is_valid_boundary_object_id,
  is_valid_envelope_id,
  is_valid_session_id,
  is_valid_any_id,
} from "../../src/kernel/ids.ts";

// ---------------------------------------------------------------------------
// Table of all 14 ID types with their generator, pattern, validator, prefix, suffix length
// ---------------------------------------------------------------------------

const ID_TYPES = [
  { name: "work_order",     gen: new_work_order_id,     pattern: WORK_ORDER_ID_PATTERN,     validator: is_valid_work_order_id,     prefix: "wo_",  suffixLen: 16 },
  { name: "policy_decision", gen: new_policy_decision_id, pattern: POLICY_DECISION_ID_PATTERN, validator: is_valid_policy_decision_id, prefix: "pd_",  suffixLen: 16 },
  { name: "invocation",     gen: new_invocation_id,     pattern: INVOCATION_ID_PATTERN,     validator: is_valid_invocation_id,     prefix: "inv_", suffixLen: 16 },
  { name: "evidence",       gen: new_evidence_id,       pattern: EVIDENCE_ID_PATTERN,       validator: is_valid_evidence_id,       prefix: "ev_",  suffixLen: 16 },
  { name: "workspace",      gen: new_workspace_id,      pattern: WORKSPACE_ID_PATTERN,      validator: is_valid_workspace_id,      prefix: "ws_",  suffixLen: 16 },
  { name: "template",       gen: new_template_id,       pattern: TEMPLATE_ID_PATTERN,       validator: is_valid_template_id,       prefix: "tpl_", suffixLen: 16 },
  { name: "assembly",       gen: new_assembly_id,       pattern: ASSEMBLY_ID_PATTERN,       validator: is_valid_assembly_id,       prefix: "asm_", suffixLen: 16 },
  { name: "escalation",     gen: new_escalation_id,     pattern: ESCALATION_ID_PATTERN,     validator: is_valid_escalation_id,     prefix: "esc_", suffixLen: 16 },
  { name: "event",          gen: new_event_id,          pattern: EVENT_ID_PATTERN,          validator: is_valid_event_id,          prefix: "evt_", suffixLen: 16 },
  { name: "bridge_request", gen: new_bridge_request_id, pattern: BRIDGE_REQUEST_ID_PATTERN, validator: is_valid_bridge_request_id, prefix: "brq_", suffixLen: 16 },
  { name: "message",        gen: new_message_id,        pattern: MESSAGE_ID_PATTERN,        validator: is_valid_message_id,        prefix: "msg_", suffixLen: 16 },
  { name: "boundary_object", gen: new_boundary_object_id, pattern: BOUNDARY_OBJECT_ID_PATTERN, validator: is_valid_boundary_object_id, prefix: "bo_",  suffixLen: 16 },
  { name: "envelope",       gen: new_envelope_id,       pattern: ENVELOPE_ID_PATTERN,       validator: is_valid_envelope_id,       prefix: "env_", suffixLen: 16 },
  { name: "session",        gen: new_session_id,        pattern: SESSION_ID_PATTERN,        validator: is_valid_session_id,        prefix: "ses_", suffixLen: 16 },
] as const;

describe("kernel/ids", () => {
  describe("generators produce correct prefix and length", () => {
    for (const { name, gen, prefix, suffixLen } of ID_TYPES) {
      test(`${name}: starts with "${prefix}" and suffix is ${suffixLen} chars`, () => {
        const id = gen();
        expect(id.startsWith(prefix)).toBe(true);
        const suffix = id.slice(prefix.length);
        expect(suffix.length).toBe(suffixLen);
      });
    }
  });

  describe("generators produce unique values", () => {
    for (const { name, gen } of ID_TYPES) {
      test(`${name}: two generated IDs are distinct`, () => {
        const a = gen();
        const b = gen();
        expect(a).not.toBe(b);
      });
    }
  });

  describe("pattern regex matches generated IDs", () => {
    for (const { name, gen, pattern } of ID_TYPES) {
      test(`${name}: generated ID matches pattern`, () => {
        const id = gen();
        expect(pattern.test(id)).toBe(true);
      });
    }
  });

  describe("validators accept valid IDs", () => {
    for (const { name, gen, validator } of ID_TYPES) {
      test(`${name}: validator returns true for generated ID`, () => {
        const id = gen();
        expect(validator(id)).toBe(true);
      });
    }
  });

  describe("validators reject invalid IDs", () => {
    for (const { name, validator } of ID_TYPES) {
      test(`${name}: validator rejects empty string`, () => {
        expect(validator("")).toBe(false);
      });

      test(`${name}: validator rejects wrong prefix`, () => {
        expect(validator("WRONG_abc123def456gh78")).toBe(false);
      });

      test(`${name}: validator rejects uppercase suffix`, () => {
        expect(validator("wo_ABC123DEF456GH78")).toBe(false);
      });
    }
  });

  describe("is_valid_any_id", () => {
    test("accepts any valid generated ID", () => {
      for (const { gen } of ID_TYPES) {
        expect(is_valid_any_id(gen())).toBe(true);
      }
    });

    test("rejects garbage string", () => {
      expect(is_valid_any_id("not_an_id_at_all")).toBe(false);
    });

    test("rejects empty string", () => {
      expect(is_valid_any_id("")).toBe(false);
    });
  });

  describe("suffix character set", () => {
    test("generated IDs contain only lowercase alphanumeric suffixes", () => {
      for (const { gen, prefix } of ID_TYPES) {
        const id = gen();
        const suffix = id.slice(prefix.length);
        expect(suffix).toMatch(/^[a-z0-9]+$/);
      }
    });
  });
});
