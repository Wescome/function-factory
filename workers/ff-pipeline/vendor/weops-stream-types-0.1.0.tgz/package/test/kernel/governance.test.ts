// test/kernel/governance.test.ts - Governance profiles and defaults tests
import { describe, test, expect } from "bun:test";

import { DEFAULT_PROFILES } from "../../src/kernel/governance.ts";
import type { GovernanceProfile } from "../../src/kernel/governance.ts";

describe("kernel/governance", () => {
  describe("DEFAULT_PROFILES", () => {
    test("has entries for G0, G1, G2, G3", () => {
      expect(DEFAULT_PROFILES["G0"]).toBeDefined();
      expect(DEFAULT_PROFILES["G1"]).toBeDefined();
      expect(DEFAULT_PROFILES["G2"]).toBeDefined();
      expect(DEFAULT_PROFILES["G3"]).toBeDefined();
    });

    test("each profile has correct governance_level", () => {
      expect(DEFAULT_PROFILES["G0"].governance_level).toBe("G0");
      expect(DEFAULT_PROFILES["G1"].governance_level).toBe("G1");
      expect(DEFAULT_PROFILES["G2"].governance_level).toBe("G2");
      expect(DEFAULT_PROFILES["G3"].governance_level).toBe("G3");
    });

    test("each profile has schema_version", () => {
      for (const level of ["G0", "G1", "G2", "G3"] as const) {
        expect(DEFAULT_PROFILES[level].schema_version).toBe("1.0.0");
      }
    });
  });

  describe("G0 profile - minimal governance", () => {
    const g0 = DEFAULT_PROFILES["G0"];

    test("pdp_mode is DISABLED", () => {
      expect(g0.enforcement_config.pdp_mode).toBe("DISABLED");
    });

    test("evidence_mode is DISABLED", () => {
      expect(g0.enforcement_config.evidence_mode).toBe("DISABLED");
    });

    test("escalation_mode is DISABLED", () => {
      expect(g0.enforcement_config.escalation_mode).toBe("DISABLED");
    });

    test("isolation_level is PROCESS", () => {
      expect(g0.enforcement_config.isolation_level).toBe("PROCESS");
    });

    test("autonomy_tier_cap is T0", () => {
      expect(g0.enforcement_config.autonomy_tier_cap).toBe("T0");
    });

    test("purpose_binding_required is false", () => {
      expect(g0.enforcement_config.purpose_binding_required).toBe(false);
    });

    test("boundary_objects_required is false", () => {
      expect(g0.enforcement_config.boundary_objects_required).toBe(false);
    });

    test("work_order_required is false", () => {
      expect(g0.enforcement_config.work_order_required).toBe(false);
    });
  });

  describe("G1 profile - basic governance", () => {
    const g1 = DEFAULT_PROFILES["G1"];

    test("pdp_mode is ROLE_ONLY", () => {
      expect(g1.enforcement_config.pdp_mode).toBe("ROLE_ONLY");
    });

    test("evidence_mode is OPTIONAL", () => {
      expect(g1.enforcement_config.evidence_mode).toBe("OPTIONAL");
    });

    test("escalation_mode is NOTIFY_ONLY", () => {
      expect(g1.enforcement_config.escalation_mode).toBe("NOTIFY_ONLY");
    });

    test("isolation_level is CONTAINER", () => {
      expect(g1.enforcement_config.isolation_level).toBe("CONTAINER");
    });

    test("purpose_binding_required is true", () => {
      expect(g1.enforcement_config.purpose_binding_required).toBe(true);
    });
  });

  describe("G2 profile - full pipeline governance", () => {
    const g2 = DEFAULT_PROFILES["G2"];

    test("pdp_mode is FULL_PIPELINE", () => {
      expect(g2.enforcement_config.pdp_mode).toBe("FULL_PIPELINE");
    });

    test("evidence_mode is MANDATORY", () => {
      expect(g2.enforcement_config.evidence_mode).toBe("MANDATORY");
    });

    test("escalation_mode is FULL_LADDER", () => {
      expect(g2.enforcement_config.escalation_mode).toBe("FULL_LADDER");
    });

    test("isolation_level is NETWORK", () => {
      expect(g2.enforcement_config.isolation_level).toBe("NETWORK");
    });

    test("all required flags are true", () => {
      expect(g2.enforcement_config.purpose_binding_required).toBe(true);
      expect(g2.enforcement_config.boundary_objects_required).toBe(true);
      expect(g2.enforcement_config.work_order_required).toBe(true);
    });
  });

  describe("G3 profile - maximum governance", () => {
    const g3 = DEFAULT_PROFILES["G3"];

    test("pdp_mode is FULL_PLUS_DUAL_CONTROL", () => {
      expect(g3.enforcement_config.pdp_mode).toBe("FULL_PLUS_DUAL_CONTROL");
    });

    test("evidence_mode is MANDATORY_PLUS_HASH_CHAIN", () => {
      expect(g3.enforcement_config.evidence_mode).toBe("MANDATORY_PLUS_HASH_CHAIN");
    });

    test("escalation_mode is FULL_LADDER_PLUS_BREAK_GLASS", () => {
      expect(g3.enforcement_config.escalation_mode).toBe("FULL_LADDER_PLUS_BREAK_GLASS");
    });

    test("isolation_level is CRYPTOGRAPHIC", () => {
      expect(g3.enforcement_config.isolation_level).toBe("CRYPTOGRAPHIC");
    });

    test("autonomy_tier_cap is T2", () => {
      expect(g3.enforcement_config.autonomy_tier_cap).toBe("T2");
    });

    test("all required flags are true", () => {
      expect(g3.enforcement_config.purpose_binding_required).toBe(true);
      expect(g3.enforcement_config.boundary_objects_required).toBe(true);
      expect(g3.enforcement_config.work_order_required).toBe(true);
    });
  });

  describe("governance level progression", () => {
    test("enforcement strictness increases from G0 to G3", () => {
      const pdp_progression = ["DISABLED", "ROLE_ONLY", "FULL_PIPELINE", "FULL_PLUS_DUAL_CONTROL"] as const;
      const levels = ["G0", "G1", "G2", "G3"] as const;

      for (let i = 0; i < levels.length; i++) {
        expect(DEFAULT_PROFILES[levels[i]!].enforcement_config.pdp_mode).toBe(pdp_progression[i]!);
      }
    });
  });
});
