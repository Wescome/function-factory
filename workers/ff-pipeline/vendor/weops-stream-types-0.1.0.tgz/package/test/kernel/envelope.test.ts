// test/kernel/envelope.test.ts - Envelope and EnvelopeResponse validation tests
import { describe, test, expect } from "bun:test";

import { validate_envelope, validate_envelope_response } from "../../src/validators/envelope.ts";
import type { Envelope, EnvelopeResponse } from "../../src/kernel/envelope.ts";
import { VALID_ENVELOPE } from "../fixtures/envelope-request.fixture.ts";
import { VALID_ENVELOPE_RESPONSE } from "../fixtures/envelope-response.fixture.ts";

describe("kernel/envelope", () => {
  describe("validate_envelope", () => {
    test("valid envelope fixture passes with zero errors", () => {
      const errors = validate_envelope(VALID_ENVELOPE);
      expect(errors).toEqual([]);
    });

    test("missing envelope_id is caught", () => {
      const bad = { ...VALID_ENVELOPE, envelope_id: "" } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.length).toBeGreaterThan(0);
      expect(errors.some((e) => e.includes("envelope_id"))).toBe(true);
    });

    test("missing correlation_id is caught", () => {
      const bad = { ...VALID_ENVELOPE, correlation_id: "" } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("correlation_id"))).toBe(true);
    });

    test("missing timestamp is caught", () => {
      const bad = { ...VALID_ENVELOPE, timestamp: "" } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("timestamp"))).toBe(true);
    });

    test("missing source is caught", () => {
      const bad = { ...VALID_ENVELOPE, source: undefined } as unknown as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("source"))).toBe(true);
    });

    test("invalid channel in source is caught", () => {
      const bad = {
        ...VALID_ENVELOPE,
        source: { ...VALID_ENVELOPE.source, channel: "INVALID" as any },
      } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("channel"))).toBe(true);
    });

    test("missing session is caught", () => {
      const bad = { ...VALID_ENVELOPE, session: undefined } as unknown as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("session"))).toBe(true);
    });

    test("missing intent is caught", () => {
      const bad = { ...VALID_ENVELOPE, intent: undefined } as unknown as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("intent"))).toBe(true);
    });

    test("missing constraint_ctx is caught", () => {
      const bad = { ...VALID_ENVELOPE, constraint_ctx: undefined } as unknown as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("constraint_ctx"))).toBe(true);
    });

    test("invalid governance_level in constraint_ctx is caught", () => {
      const bad = {
        ...VALID_ENVELOPE,
        constraint_ctx: { ...VALID_ENVELOPE.constraint_ctx, governance_level: "G9" as any },
      } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("governance_level"))).toBe(true);
    });
  });

  describe("validate_envelope_response", () => {
    test("valid response fixture passes with zero errors", () => {
      const errors = validate_envelope_response(VALID_ENVELOPE_RESPONSE);
      expect(errors).toEqual([]);
    });

    test("missing envelope_id is caught", () => {
      const bad = { ...VALID_ENVELOPE_RESPONSE, envelope_id: "" } as EnvelopeResponse;
      const errors = validate_envelope_response(bad);
      expect(errors.some((e) => e.includes("envelope_id"))).toBe(true);
    });

    test("invalid status is caught", () => {
      const bad = { ...VALID_ENVELOPE_RESPONSE, status: "INVALID" as any } as EnvelopeResponse;
      const errors = validate_envelope_response(bad);
      expect(errors.some((e) => e.includes("status"))).toBe(true);
    });

    test("invalid governance_applied.decision is caught", () => {
      const bad = {
        ...VALID_ENVELOPE_RESPONSE,
        governance_applied: {
          ...VALID_ENVELOPE_RESPONSE.governance_applied!,
          decision: "MAYBE" as any,
        },
      } as EnvelopeResponse;
      const errors = validate_envelope_response(bad);
      expect(errors.some((e) => e.includes("decision"))).toBe(true);
    });
  });
});
