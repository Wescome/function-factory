// test/coordination/workspace.test.ts
import { describe, test, expect } from "bun:test";
import {
  OWNER_TYPE_VALUES,
  COORD_WORKSPACE_STATUS_VALUES,
  validate_coord_workspace_transition,
  validate_governance_upgrade,
} from "../../src/coordination/index.ts";

describe("coordination/workspace", () => {
  describe("OWNER_TYPE_VALUES", () => {
    test("has USER, TEAM, ORGANIZATION", () => {
      expect(OWNER_TYPE_VALUES).toContain("USER");
      expect(OWNER_TYPE_VALUES).toContain("TEAM");
      expect(OWNER_TYPE_VALUES).toContain("ORGANIZATION");
      expect(OWNER_TYPE_VALUES.length).toBe(3);
    });
  });

  describe("workspace status transitions", () => {
    test("PROVISIONING can transition to ACTIVE", () => {
      expect(validate_coord_workspace_transition("PROVISIONING", "ACTIVE")).toBe(true);
    });

    test("PROVISIONING cannot transition to SUSPENDED", () => {
      expect(validate_coord_workspace_transition("PROVISIONING", "SUSPENDED")).toBe(false);
    });

    test("ACTIVE can transition to SUSPENDED or ARCHIVED", () => {
      expect(validate_coord_workspace_transition("ACTIVE", "SUSPENDED")).toBe(true);
      expect(validate_coord_workspace_transition("ACTIVE", "ARCHIVED")).toBe(true);
    });

    test("ACTIVE cannot transition back to PROVISIONING", () => {
      expect(validate_coord_workspace_transition("ACTIVE", "PROVISIONING")).toBe(false);
    });

    test("SUSPENDED can transition to ACTIVE or ARCHIVED", () => {
      expect(validate_coord_workspace_transition("SUSPENDED", "ACTIVE")).toBe(true);
      expect(validate_coord_workspace_transition("SUSPENDED", "ARCHIVED")).toBe(true);
    });

    test("ARCHIVED is terminal — no transitions", () => {
      for (const status of COORD_WORKSPACE_STATUS_VALUES) {
        expect(validate_coord_workspace_transition("ARCHIVED", status)).toBe(false);
      }
    });
  });

  describe("governance upgrade validation", () => {
    test("same level is valid", () => {
      expect(validate_governance_upgrade("G0", "G0")).toBe(true);
      expect(validate_governance_upgrade("G2", "G2")).toBe(true);
    });

    test("upgrade is valid", () => {
      expect(validate_governance_upgrade("G0", "G1")).toBe(true);
      expect(validate_governance_upgrade("G0", "G3")).toBe(true);
      expect(validate_governance_upgrade("G1", "G2")).toBe(true);
      expect(validate_governance_upgrade("G2", "G3")).toBe(true);
    });

    test("downgrade is invalid", () => {
      expect(validate_governance_upgrade("G1", "G0")).toBe(false);
      expect(validate_governance_upgrade("G2", "G1")).toBe(false);
      expect(validate_governance_upgrade("G3", "G0")).toBe(false);
    });
  });
});
