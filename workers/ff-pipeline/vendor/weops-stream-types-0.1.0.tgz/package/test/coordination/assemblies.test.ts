// test/coordination/assemblies.test.ts
import { describe, test, expect } from "bun:test";
import {
  ALL_ASSEMBLIES,
  ALL_TEMPLATES,
  CANVAS_ASSEMBLY,
  COGNIFIQ_ASSEMBLY,
  COMMON_GROUND_ASSEMBLY,
  WELLWISH_ASSEMBLY,
  TPL_CANVAS_PERSONAL,
  TPL_COGNIFIQ_TEAM,
  TPL_WELLWISH_CARE,
  TPL_WELLWISH_ENTERPRISE,
  find_assembly,
  find_template,
  templates_for_assembly,
} from "../../src/coordination/index.ts";

describe("coordination/assemblies", () => {
  describe("product assemblies", () => {
    test("ALL_ASSEMBLIES has 4 entries", () => {
      expect(ALL_ASSEMBLIES.length).toBe(4);
    });

    test("Canvas.ceo has G0-G1 governance range", () => {
      expect(CANVAS_ASSEMBLY.governance_range.min).toBe("G0");
      expect(CANVAS_ASSEMBLY.governance_range.max).toBe("G1");
    });

    test("Canvas.ceo has DA, DI, SM, RE contexts", () => {
      expect(CANVAS_ASSEMBLY.domain_contexts).toEqual(["DA", "DI", "SM", "RE"]);
    });

    test("Cognifiq has G2-G3 governance range", () => {
      expect(COGNIFIQ_ASSEMBLY.governance_range.min).toBe("G2");
      expect(COGNIFIQ_ASSEMBLY.governance_range.max).toBe("G3");
    });

    test("Cognifiq has DA, DI, CC, RA, RE contexts", () => {
      expect(COGNIFIQ_ASSEMBLY.domain_contexts).toEqual(["DA", "DI", "CC", "RA", "RE"]);
    });

    test("Common Ground has G1-G2 governance range", () => {
      expect(COMMON_GROUND_ASSEMBLY.governance_range.min).toBe("G1");
      expect(COMMON_GROUND_ASSEMBLY.governance_range.max).toBe("G2");
    });

    test("WellWish has G2-G3 governance range", () => {
      expect(WELLWISH_ASSEMBLY.governance_range.min).toBe("G2");
      expect(WELLWISH_ASSEMBLY.governance_range.max).toBe("G3");
    });

    test("each assembly has schema_version 1.0.0", () => {
      for (const a of ALL_ASSEMBLIES) {
        expect(a.schema_version).toBe("1.0.0");
      }
    });
  });

  describe("workspace templates", () => {
    test("ALL_TEMPLATES has 8 entries", () => {
      expect(ALL_TEMPLATES.length).toBe(8);
    });

    test("Canvas personal is G0 with LOCAL_SQLITE", () => {
      expect(TPL_CANVAS_PERSONAL.governance_level).toBe("G0");
      expect(TPL_CANVAS_PERSONAL.infrastructure_profile).toBe("LOCAL_SQLITE");
    });

    test("Cognifiq team is G2 with MANAGED_PG", () => {
      expect(TPL_COGNIFIQ_TEAM.governance_level).toBe("G2");
      expect(TPL_COGNIFIQ_TEAM.infrastructure_profile).toBe("MANAGED_PG");
    });

    test("WellWish care has PHI policy bundle", () => {
      expect(TPL_WELLWISH_CARE.default_policy_bundles).toContain("urn:weops:policy:phi-governance:1.0.0");
    });

    test("WellWish enterprise has PHI + HIPAA bundles", () => {
      expect(TPL_WELLWISH_ENTERPRISE.default_policy_bundles).toContain("urn:weops:policy:phi-governance:1.0.0");
      expect(TPL_WELLWISH_ENTERPRISE.default_policy_bundles).toContain("urn:weops:policy:hipaa-minimum-necessary:1.0.0");
    });

    test("WellWish enterprise is G3 with FEDRAMP_HSM", () => {
      expect(TPL_WELLWISH_ENTERPRISE.governance_level).toBe("G3");
      expect(TPL_WELLWISH_ENTERPRISE.infrastructure_profile).toBe("FEDRAMP_HSM");
    });
  });

  describe("lookup helpers", () => {
    test("find_assembly returns Canvas by ID", () => {
      const a = find_assembly("asm_canvas");
      expect(a).toBeDefined();
      expect(a!.product_name).toBe("Canvas.ceo");
    });

    test("find_assembly returns undefined for unknown ID", () => {
      expect(find_assembly("asm_unknown")).toBeUndefined();
    });

    test("find_template returns Cognifiq team by ID", () => {
      const t = find_template("tpl_cognifiq_team");
      expect(t).toBeDefined();
      expect(t!.governance_level).toBe("G2");
    });

    test("templates_for_assembly returns correct templates", () => {
      const templates = templates_for_assembly("asm_canvas");
      expect(templates.length).toBe(2);
      const ids = templates.map(t => t.template_id as string);
      expect(ids).toContain("tpl_canvas_personal");
      expect(ids).toContain("tpl_canvas_team");
    });

    test("templates_for_assembly returns empty for unknown", () => {
      expect(templates_for_assembly("asm_unknown")).toEqual([]);
    });
  });
});
