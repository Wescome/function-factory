// test/coordination/validators.test.ts
import { describe, test, expect } from "bun:test";
import {
  validate_workspace,
  validate_template,
  validate_product_assembly,
  validate_domain_context_manifest,
  validate_bridge_request,
} from "../../src/coordination/index.ts";
import { new_workspace_id, new_bridge_request_id } from "../../src/kernel/ids.ts";
import type { Workspace } from "../../src/coordination/workspace.ts";
import type { WorkspaceTemplate } from "../../src/coordination/template.ts";
import type { ProductAssembly } from "../../src/coordination/product-assembly.ts";
import type { DomainContextManifest } from "../../src/coordination/domain-context.ts";
import type { BridgeRequest } from "../../src/coordination/bridge.ts";
import type { WorkspaceID, TemplateID, AssemblyID } from "../../src/kernel/ids.ts";

function make_valid_workspace(): Workspace {
  return {
    workspace_id: new_workspace_id(),
    owner: { owner_type: "USER", owner_id: "user_123" },
    governance_level: "G2",
    isolation_level: "NETWORK",
    status: "ACTIVE",
    domain_contexts: ["IC", "OR", "RE"],
    purpose_scope: [],
    policy_bundles: [],
    members: [{ member_id: "user_123", role: "OWNER" }],
    created_at: new Date().toISOString(),
    schema_version: "1.0.0",
  };
}

function make_valid_template(): WorkspaceTemplate {
  return {
    template_id: "tpl_test_workspace_01" as unknown as TemplateID,
    template_name: "Test Template",
    governance_level: "G1",
    domain_contexts: ["IC", "RE"],
    purpose_scope: [],
    default_policy_bundles: [],
    infrastructure_profile: "MANAGED_PG",
    version: "1.0.0",
    schema_version: "1.0.0",
  };
}

function make_valid_assembly(): ProductAssembly {
  return {
    assembly_id: "asm_test_product" as unknown as AssemblyID,
    product_name: "Test Product",
    templates: ["tpl_test_01"],
    domain_contexts: ["IC", "RE"],
    governance_range: { min: "G1", max: "G2" },
    version: "1.0.0",
    schema_version: "1.0.0",
  };
}

function make_valid_manifest(): DomainContextManifest {
  return {
    context_id: "IC",
    context_name: "Identity & Context",
    capabilities: [{ capability_id: "identity_create", tool_schema_ref: "urn:weops:tool:identity:create" }],
    events_published: [{ event_type: "identity.created", schema_ref: "urn:weops:event:identity.created:1.0.0" }],
    events_consumed: [{ event_type: "orchestration.work_order_completed", handler: "on_work_order_completed" }],
    version: "1.0.0",
    schema_version: "1.0.0",
  };
}

function make_valid_bridge_request(): BridgeRequest {
  return {
    bridge_request_id: new_bridge_request_id(),
    source_workspace_id: "ws_source_abc123" as unknown as WorkspaceID,
    target_workspace_id: "ws_target_def456" as unknown as WorkspaceID,
    requested_object_type: "CB-01",
    requested_object_id: "bo_abc123",
    purpose: "OPERATIONS.VENDOR_ONBOARDING",
    requester_claims: { actor: "user_123", role: "MEMBER", session: "ses_abc" },
    field_filter: ["summary", "status"],
    status: "PENDING",
    created_at: new Date().toISOString(),
    schema_version: "1.0.0",
  };
}

describe("coordination/validators", () => {
  describe("validate_workspace", () => {
    test("valid workspace returns no errors", () => {
      expect(validate_workspace(make_valid_workspace())).toEqual([]);
    });

    test("missing workspace_id returns error", () => {
      const ws = { ...make_valid_workspace(), workspace_id: "" as any };
      expect(validate_workspace(ws).length).toBeGreaterThan(0);
    });

    test("invalid governance_level returns error", () => {
      const ws = { ...make_valid_workspace(), governance_level: "G5" as any };
      expect(validate_workspace(ws).some(e => e.includes("governance_level"))).toBe(true);
    });

    test("empty domain_contexts returns error", () => {
      const ws = { ...make_valid_workspace(), domain_contexts: [] as any };
      expect(validate_workspace(ws).some(e => e.includes("domain_contexts"))).toBe(true);
    });

    test("invalid domain_context ID returns error", () => {
      const ws = { ...make_valid_workspace(), domain_contexts: ["IC", "XX" as any] };
      expect(validate_workspace(ws).some(e => e.includes("XX"))).toBe(true);
    });
  });

  describe("validate_template", () => {
    test("valid template returns no errors", () => {
      expect(validate_template(make_valid_template())).toEqual([]);
    });

    test("invalid infrastructure_profile returns error", () => {
      const t = { ...make_valid_template(), infrastructure_profile: "BARE_METAL" as any };
      expect(validate_template(t).some(e => e.includes("infrastructure_profile"))).toBe(true);
    });

    test("invalid version format returns error", () => {
      const t = { ...make_valid_template(), version: "v1" };
      expect(validate_template(t).some(e => e.includes("version"))).toBe(true);
    });
  });

  describe("validate_product_assembly", () => {
    test("valid assembly returns no errors", () => {
      expect(validate_product_assembly(make_valid_assembly())).toEqual([]);
    });

    test("empty templates returns error", () => {
      const a = { ...make_valid_assembly(), templates: [] as any };
      expect(validate_product_assembly(a).some(e => e.includes("templates"))).toBe(true);
    });

    test("inverted governance range returns error", () => {
      const a = { ...make_valid_assembly(), governance_range: { min: "G3" as const, max: "G1" as const } };
      expect(validate_product_assembly(a).some(e => e.includes("governance_range"))).toBe(true);
    });
  });

  describe("validate_domain_context_manifest", () => {
    test("valid manifest returns no errors", () => {
      expect(validate_domain_context_manifest(make_valid_manifest())).toEqual([]);
    });

    test("invalid context_id returns error", () => {
      const m = { ...make_valid_manifest(), context_id: "XX" as any };
      expect(validate_domain_context_manifest(m).some(e => e.includes("context_id"))).toBe(true);
    });
  });

  describe("validate_bridge_request", () => {
    test("valid bridge request returns no errors", () => {
      expect(validate_bridge_request(make_valid_bridge_request())).toEqual([]);
    });

    test("same source and target workspace returns error", () => {
      const br = make_valid_bridge_request();
      const b = { ...br, target_workspace_id: br.source_workspace_id };
      expect(validate_bridge_request(b).some(e => e.includes("different"))).toBe(true);
    });

    test("missing purpose returns error", () => {
      const b = { ...make_valid_bridge_request(), purpose: "" };
      expect(validate_bridge_request(b).some(e => e.includes("purpose"))).toBe(true);
    });
  });
});
