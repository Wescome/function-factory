// test/coordination/router.test.ts
import { describe, test, expect } from "bun:test";
import {
  DEFAULT_IMPACT_RULES,
  ROUTE_DECISION_VALUES,
  max_governance_level,
  governance_level_gte,
  governance_level_gt,
} from "../../src/coordination/index.ts";

describe("coordination/router", () => {
  describe("DEFAULT_IMPACT_RULES", () => {
    test("has 6 rules", () => {
      expect(DEFAULT_IMPACT_RULES.length).toBe(6);
    });

    test("external_api_call requires G1", () => {
      const rule = DEFAULT_IMPACT_RULES.find(r => r.action_pattern === "external_api_call");
      expect(rule).toBeDefined();
      expect(rule!.min_governance).toBe("G1");
    });

    test("phi_access requires G2", () => {
      const rule = DEFAULT_IMPACT_RULES.find(r => r.action_pattern === "phi_access");
      expect(rule).toBeDefined();
      expect(rule!.min_governance).toBe("G2");
    });

    test("external_disclosure requires G3", () => {
      const rule = DEFAULT_IMPACT_RULES.find(r => r.action_pattern === "external_disclosure");
      expect(rule).toBeDefined();
      expect(rule!.min_governance).toBe("G3");
    });

    test("policy_bundle_modification requires G3", () => {
      const rule = DEFAULT_IMPACT_RULES.find(r => r.action_pattern === "policy_bundle_modification");
      expect(rule).toBeDefined();
      expect(rule!.min_governance).toBe("G3");
    });
  });

  describe("governance level comparison", () => {
    test("max_governance_level returns higher level", () => {
      expect(max_governance_level("G0", "G2")).toBe("G2");
      expect(max_governance_level("G3", "G1")).toBe("G3");
      expect(max_governance_level("G1", "G1")).toBe("G1");
    });

    test("governance_level_gte works correctly", () => {
      expect(governance_level_gte("G2", "G0")).toBe(true);
      expect(governance_level_gte("G2", "G2")).toBe(true);
      expect(governance_level_gte("G0", "G2")).toBe(false);
    });

    test("governance_level_gt works correctly", () => {
      expect(governance_level_gt("G2", "G0")).toBe(true);
      expect(governance_level_gt("G2", "G2")).toBe(false);
      expect(governance_level_gt("G0", "G2")).toBe(false);
    });
  });

  describe("ROUTE_DECISION_VALUES", () => {
    test("has PERMIT, DENY, ESCALATE_AND_EVALUATE", () => {
      expect(ROUTE_DECISION_VALUES).toContain("PERMIT");
      expect(ROUTE_DECISION_VALUES).toContain("DENY");
      expect(ROUTE_DECISION_VALUES).toContain("ESCALATE_AND_EVALUATE");
    });
  });
});
