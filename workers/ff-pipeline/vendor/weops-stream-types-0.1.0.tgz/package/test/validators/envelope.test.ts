// test/validators/envelope.test.ts - Envelope validation tests via validator module
import { describe, test, expect } from "bun:test";

import { validate_envelope, validate_envelope_response } from "../../src/validators/envelope.ts";
import type { Envelope, EnvelopeResponse } from "../../src/kernel/envelope.ts";
import { VALID_ENVELOPE } from "../fixtures/envelope-request.fixture.ts";
import { VALID_ENVELOPE_RESPONSE } from "../fixtures/envelope-response.fixture.ts";

describe("validators/envelope", () => {
  describe("validate_envelope", () => {
    test("valid fixture passes with zero errors", () => {
      const errors = validate_envelope(VALID_ENVELOPE);
      expect(errors).toEqual([]);
    });

    test("missing envelope_id caught", () => {
      const bad = { ...VALID_ENVELOPE, envelope_id: "" } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("envelope_id"))).toBe(true);
    });

    test("missing channel caught via source", () => {
      const bad = {
        ...VALID_ENVELOPE,
        source: { ...VALID_ENVELOPE.source, channel: "FAKE" as any },
      } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("channel"))).toBe(true);
    });

    test("missing session_id in session caught", () => {
      const bad = {
        ...VALID_ENVELOPE,
        session: { ...VALID_ENVELOPE.session, session_id: "" },
      } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("session_id"))).toBe(true);
    });

    test("invalid active_role caught", () => {
      const bad = {
        ...VALID_ENVELOPE,
        session: { ...VALID_ENVELOPE.session, active_role: "SUPERUSER" as any },
      } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("active_role"))).toBe(true);
    });

    test("invalid intent_type caught", () => {
      const bad = {
        ...VALID_ENVELOPE,
        intent: { ...VALID_ENVELOPE.intent, intent_type: "invalid.intent" as any },
      } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("intent_type"))).toBe(true);
    });

    test("missing purpose in constraint_ctx caught", () => {
      const bad = {
        ...VALID_ENVELOPE,
        constraint_ctx: { ...VALID_ENVELOPE.constraint_ctx, purpose: "" },
      } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("purpose"))).toBe(true);
    });

    test("invalid classification caught", () => {
      const bad = {
        ...VALID_ENVELOPE,
        constraint_ctx: { ...VALID_ENVELOPE.constraint_ctx, classification: "TOP_SECRET" as any },
      } as Envelope;
      const errors = validate_envelope(bad);
      expect(errors.some((e) => e.includes("classification"))).toBe(true);
    });
  });

  describe("validate_envelope_response", () => {
    test("valid response fixture passes with zero errors", () => {
      const errors = validate_envelope_response(VALID_ENVELOPE_RESPONSE);
      expect(errors).toEqual([]);
    });

    test("missing correlation_id caught", () => {
      const bad = { ...VALID_ENVELOPE_RESPONSE, correlation_id: "" } as EnvelopeResponse;
      const errors = validate_envelope_response(bad);
      expect(errors.some((e) => e.includes("correlation_id"))).toBe(true);
    });

    test("invalid status caught", () => {
      const bad = { ...VALID_ENVELOPE_RESPONSE, status: "unknown" as any } as EnvelopeResponse;
      const errors = validate_envelope_response(bad);
      expect(errors.some((e) => e.includes("status"))).toBe(true);
    });

    test("invalid governance_applied.effective_level caught", () => {
      const bad = {
        ...VALID_ENVELOPE_RESPONSE,
        governance_applied: {
          ...VALID_ENVELOPE_RESPONSE.governance_applied!,
          effective_level: "G9" as any,
        },
      } as EnvelopeResponse;
      const errors = validate_envelope_response(bad);
      expect(errors.some((e) => e.includes("effective_level"))).toBe(true);
    });
  });
});
