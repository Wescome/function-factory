// test/validators/ids.test.ts - ID validator function tests
import { describe, test, expect } from "bun:test";

import { validate_id, detect_id_type } from "../../src/validators/ids.ts";
import {
  new_work_order_id,
  new_policy_decision_id,
  new_invocation_id,
  new_evidence_id,
  new_workspace_id,
  new_template_id,
  new_assembly_id,
  new_escalation_id,
  new_event_id,
  new_bridge_request_id,
  new_message_id,
  new_boundary_object_id,
  new_envelope_id,
  new_session_id,
} from "../../src/kernel/ids.ts";

// ---------------------------------------------------------------------------
// Type -> generator -> prefix mapping
// ---------------------------------------------------------------------------
const ID_TYPES = [
  { type: "work_order",      gen: new_work_order_id,      prefix: "wo_" },
  { type: "policy_decision", gen: new_policy_decision_id, prefix: "pd_" },
  { type: "invocation",      gen: new_invocation_id,      prefix: "inv_" },
  { type: "evidence",        gen: new_evidence_id,        prefix: "ev_" },
  { type: "workspace",       gen: new_workspace_id,       prefix: "ws_" },
  { type: "template",        gen: new_template_id,        prefix: "tpl_" },
  { type: "assembly",        gen: new_assembly_id,        prefix: "asm_" },
  { type: "escalation",      gen: new_escalation_id,      prefix: "esc_" },
  { type: "event",           gen: new_event_id,           prefix: "evt_" },
  { type: "bridge_request",  gen: new_bridge_request_id,  prefix: "brq_" },
  { type: "message",         gen: new_message_id,         prefix: "msg_" },
  { type: "boundary_object", gen: new_boundary_object_id, prefix: "bo_" },
  { type: "envelope",        gen: new_envelope_id,        prefix: "env_" },
  { type: "session",         gen: new_session_id,         prefix: "ses_" },
] as const;

describe("validators/ids", () => {
  describe("validate_id - valid IDs pass", () => {
    for (const { type, gen } of ID_TYPES) {
      test(`${type}: generated ID validates with zero errors`, () => {
        const id = gen();
        const errors = validate_id(id, type);
        expect(errors).toEqual([]);
      });
    }
  });

  describe("validate_id - wrong prefix fails", () => {
    for (const { type } of ID_TYPES) {
      test(`${type}: ID with wrong prefix is rejected`, () => {
        const errors = validate_id("WRONG_abc123def456gh78", type);
        expect(errors.length).toBeGreaterThan(0);
      });
    }
  });

  describe("validate_id - wrong length fails", () => {
    for (const { type, prefix } of ID_TYPES) {
      // Skip workspace which has variable length pattern
      if (type === "workspace") continue;
      test(`${type}: ID with short suffix is rejected`, () => {
        const errors = validate_id(prefix + "abc", type);
        expect(errors.length).toBeGreaterThan(0);
      });
    }
  });

  describe("validate_id - invalid chars fail", () => {
    for (const { type, prefix } of ID_TYPES) {
      // Skip workspace which allows underscores
      if (type === "workspace") continue;
      test(`${type}: ID with uppercase chars is rejected`, () => {
        const errors = validate_id(prefix + "ABCDEFGHIJKLMNOP", type);
        expect(errors.length).toBeGreaterThan(0);
      });
    }
  });

  describe("validate_id - empty ID", () => {
    test("empty ID returns error", () => {
      const errors = validate_id("", "work_order");
      expect(errors.length).toBeGreaterThan(0);
      expect(errors[0]).toContain("must not be empty");
    });
  });

  describe("validate_id - unknown type", () => {
    test("unknown type returns error", () => {
      const errors = validate_id("test_abc123", "unknown_type");
      expect(errors.length).toBeGreaterThan(0);
      expect(errors[0]).toContain("unknown id type");
    });
  });

  describe("detect_id_type", () => {
    for (const { type, gen } of ID_TYPES) {
      test(`${type}: detects correct type from generated ID`, () => {
        const id = gen();
        const detected = detect_id_type(id);
        expect(detected).toBe(type);
      });
    }

    test("returns null for unknown prefix", () => {
      expect(detect_id_type("zzz_abc123def456gh78")).toBeNull();
    });

    test("returns null for empty string", () => {
      expect(detect_id_type("")).toBeNull();
    });
  });
});
