// test/mappers/work-order.mapper.test.ts - WorkOrder to WorkOrderDataPart mapper tests
import { describe, test, expect } from "bun:test";

import { to_work_order_data_part } from "../../src/mappers/work-order.mapper.ts";
import type { WorkOrder } from "../../src/kernel/workorder.ts";

const SAMPLE_WORK_ORDER: WorkOrder = {
  work_order_id: "wo_abc123def456gh78",
  workspace_id: "ws_primary_care",
  schema_version: "1.0.0",
  version: "1",
  parent_work_order_id: "wo_parent00000001ab",
  primary_purpose: "TREATMENT.CARE_COORDINATION",
  acting_role: "MEMBER",
  stakeholders: ["usr-001", "usr-002"],
  autonomy_tier: "T1",
  risk_tier: "R2",
  decision_rule_on_conflict: "MOST_RESTRICTIVE_WINS",
  status: "APPROVED",
  required_approvals: [
    {
      type: "governance",
      status: "GRANTED",
      by: "ADMIN",
      timestamp: "2026-02-16T12:00:00.000Z",
    },
  ],
};

describe("mappers/work-order", () => {
  describe("to_work_order_data_part", () => {
    test("preserves work_order_id", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.work_order_id).toBe("wo_abc123def456gh78");
    });

    test("preserves status", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.status).toBe("APPROVED");
    });

    test("preserves primary_purpose", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.primary_purpose).toBe("TREATMENT.CARE_COORDINATION");
    });

    test("preserves acting_role", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.acting_role).toBe("MEMBER");
    });

    test("preserves autonomy_tier and risk_tier", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.autonomy_tier).toBe("T1");
      expect(result.risk_tier).toBe("R2");
    });

    test("preserves parent_work_order_id", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.parent_work_order_id).toBe("wo_parent00000001ab");
    });

    test("sets parent_work_order_id to null when absent", () => {
      const wo = { ...SAMPLE_WORK_ORDER, parent_work_order_id: undefined };
      const result = to_work_order_data_part(wo);
      expect(result.parent_work_order_id).toBeNull();
    });

    test("preserves decision_rule_on_conflict", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.decision_rule_on_conflict).toBe("MOST_RESTRICTIVE_WINS");
    });

    test("defaults decision_rule_on_conflict to ESCALATE_WITH_OPTIONS_MEMO", () => {
      const wo = { ...SAMPLE_WORK_ORDER, decision_rule_on_conflict: undefined };
      const result = to_work_order_data_part(wo);
      expect(result.decision_rule_on_conflict).toBe("ESCALATE_WITH_OPTIONS_MEMO");
    });

    test("copies stakeholders as new array", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.stakeholders).toEqual(["usr-001", "usr-002"]);
      // verify it's a copy, not the same reference
      expect(result.stakeholders).not.toBe(SAMPLE_WORK_ORDER.stakeholders);
    });

    test("maps required_approvals to pending_approvals", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.pending_approvals.length).toBe(1);
      expect(result.pending_approvals[0]!.type).toBe("governance");
      expect(result.pending_approvals[0]!.status).toBe("GRANTED");
    });

    test("sets compensation_sub_state to null", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.compensation_sub_state).toBeNull();
    });

    test("generates a valid ISO timestamp", () => {
      const result = to_work_order_data_part(SAMPLE_WORK_ORDER);
      expect(result.timestamp).toBeTruthy();
      // should parse as a valid date
      const parsed = new Date(result.timestamp);
      expect(parsed.getTime()).not.toBeNaN();
    });
  });
});
