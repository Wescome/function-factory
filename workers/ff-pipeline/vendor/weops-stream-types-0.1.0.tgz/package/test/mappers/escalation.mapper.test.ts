// test/mappers/escalation.mapper.test.ts - Escalation mapper tests
import { describe, test, expect } from "bun:test";

import { to_escalation_data_part } from "../../src/mappers/escalation.mapper.ts";
import type { GovernanceEscalation } from "../../src/kernel/escalation.ts";

const G1_TO_G2_ESCALATION: GovernanceEscalation = {
  escalation_id: "esc_abc123def456gh78",
  workspace_id: "ws_primary_care",
  current_level: "G1",
  requested_level: "G2",
  trigger: {
    trigger_type: "PHI_DETECTED",
    trigger_details: { field: "patient_name", confidence: 0.98 },
  },
  status: "PENDING",
  schema_version: "1.0.0",
};

describe("mappers/escalation", () => {
  describe("to_escalation_data_part", () => {
    test("maps escalation_id", () => {
      const result = to_escalation_data_part(G1_TO_G2_ESCALATION);
      expect(result.escalation_id).toBe("esc_abc123def456gh78");
    });

    test("maps governance level G2 to rung 3 (Approval)", () => {
      const result = to_escalation_data_part(G1_TO_G2_ESCALATION);
      expect(result.rung).toBe(3);
      expect(result.rung_name).toBe("Approval");
    });

    test("maps governance level G0 to rung 0 (Clarify)", () => {
      const esc = { ...G1_TO_G2_ESCALATION, requested_level: "G0" as const };
      const result = to_escalation_data_part(esc);
      expect(result.rung).toBe(0);
      expect(result.rung_name).toBe("Clarify");
    });

    test("maps governance level G1 to rung 1 (Constrain)", () => {
      const esc = { ...G1_TO_G2_ESCALATION, requested_level: "G1" as const };
      const result = to_escalation_data_part(esc);
      expect(result.rung).toBe(1);
      expect(result.rung_name).toBe("Constrain");
    });

    test("maps governance level G3 to rung 5 (Deny + log)", () => {
      const esc = { ...G1_TO_G2_ESCALATION, requested_level: "G3" as const };
      const result = to_escalation_data_part(esc);
      expect(result.rung).toBe(5);
      expect(result.rung_name).toBe("Deny + log");
    });

    test("maps trigger type", () => {
      const result = to_escalation_data_part(G1_TO_G2_ESCALATION);
      expect(result.trigger).toBe("PHI_DETECTED");
    });

    test("serializes trigger_details to JSON string", () => {
      const result = to_escalation_data_part(G1_TO_G2_ESCALATION);
      expect(result.trigger_detail).toContain("patient_name");
      expect(result.trigger_detail).toContain("0.98");
    });

    test("PENDING status means not resolved", () => {
      const result = to_escalation_data_part(G1_TO_G2_ESCALATION);
      expect(result.resolved).toBe(false);
      expect(result.resolved_at).toBeNull();
    });

    test("APPLIED status means resolved", () => {
      const esc = {
        ...G1_TO_G2_ESCALATION,
        status: "APPLIED" as const,
        applied_at: "2026-02-16T12:30:00.000Z",
      };
      const result = to_escalation_data_part(esc);
      expect(result.resolved).toBe(true);
      expect(result.resolved_at).toBe("2026-02-16T12:30:00.000Z");
    });

    test("DENIED status means resolved", () => {
      const esc = { ...G1_TO_G2_ESCALATION, status: "DENIED" as const };
      const result = to_escalation_data_part(esc);
      expect(result.resolved).toBe(true);
    });

    test("sets required_actions as empty array", () => {
      const result = to_escalation_data_part(G1_TO_G2_ESCALATION);
      expect(result.required_actions).toEqual([]);
    });
  });
});
