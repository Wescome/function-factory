// test/mappers/governance.mapper.test.ts - Governance mapper tests
import { describe, test, expect } from "bun:test";

import { to_governance_data_part } from "../../src/mappers/governance.mapper.ts";
import type { GovernanceApplied } from "../../src/kernel/envelope.ts";
import type { DecisionResponse } from "../../src/kernel/policy.ts";

const APPLIED: GovernanceApplied = {
  effective_level: "G2",
  pdp_evaluated: true,
  decision: "PERMIT",
  policy_decision_id: "pd_abc123def456gh78",
};

const RESPONSE: DecisionResponse = {
  policy_decision_id: "pd_abc123def456gh78",
  decision: "PERMIT",
  reasons: ["ROLE_MATCH", "PURPOSE_VALID"],
  obligations: [
    { type: "REQUIRE_EVIDENCE_BUNDLE", severity: "HIGH" },
    { type: "LOG_LEVEL", value: "DETAILED" },
  ],
  escalation_rung: 2,
  evaluated_at: "2026-02-16T12:00:00.000Z",
  policy_version: "1.0.0",
};

describe("mappers/governance", () => {
  describe("to_governance_data_part", () => {
    test("maps policy_decision_id from response", () => {
      const result = to_governance_data_part(APPLIED, RESPONSE, "wo_test1234567890ab");
      expect(result.policy_decision_id).toBe("pd_abc123def456gh78");
    });

    test("maps decision from applied", () => {
      const result = to_governance_data_part(APPLIED, RESPONSE, "wo_test1234567890ab");
      expect(result.decision).toBe("PERMIT");
    });

    test("maps reasons from response", () => {
      const result = to_governance_data_part(APPLIED, RESPONSE, "wo_test1234567890ab");
      expect(result.reasons.length).toBe(2);
      expect(result.reasons[0]!.code).toBe("ROLE_MATCH");
      expect(result.reasons[1]!.code).toBe("PURPOSE_VALID");
    });

    test("each reason has severity and summary fields", () => {
      const result = to_governance_data_part(APPLIED, RESPONSE, "wo_test1234567890ab");
      for (const reason of result.reasons) {
        expect(reason.severity).toBe("INFO");
        expect(reason.summary).toBeTruthy();
        expect(reason.detail).toBeTruthy();
        expect(reason.next_steps).toBeNull();
      }
    });

    test("maps obligations from response", () => {
      const result = to_governance_data_part(APPLIED, RESPONSE, "wo_test1234567890ab");
      expect(result.obligations.length).toBe(2);
      expect(result.obligations[0]!.type).toBe("REQUIRE_EVIDENCE_BUNDLE");
      expect(result.obligations[1]!.type).toBe("LOG_LEVEL");
    });

    test("obligations are initially unsatisfied", () => {
      const result = to_governance_data_part(APPLIED, RESPONSE, "wo_test1234567890ab");
      for (const obl of result.obligations) {
        expect(obl.satisfied).toBe(false);
      }
    });

    test("maps escalation_rung from response", () => {
      const result = to_governance_data_part(APPLIED, RESPONSE, "wo_test1234567890ab");
      expect(result.escalation_rung).toBe(2);
    });

    test("sets escalation_rung to null when absent", () => {
      const no_esc_response = { ...RESPONSE, escalation_rung: undefined };
      const result = to_governance_data_part(APPLIED, no_esc_response, "wo_test1234567890ab");
      expect(result.escalation_rung).toBeNull();
    });

    test("sets correct type discriminator fields", () => {
      const result = to_governance_data_part(APPLIED, RESPONSE, "wo_test1234567890ab");
      expect(result.work_order_id).toBe("wo_test1234567890ab");
      expect(result.timestamp).toBe("2026-02-16T12:00:00.000Z");
    });

    test("passes optional invocation_id and tool_id", () => {
      const result = to_governance_data_part(
        APPLIED,
        RESPONSE,
        "wo_test1234567890ab",
        "inv_test1234567890ab",
        "ehr.read_patient",
      );
      expect(result.invocation_id).toBe("inv_test1234567890ab");
      expect(result.tool_id).toBe("ehr.read_patient");
    });

    test("defaults invocation_id and tool_id to null", () => {
      const result = to_governance_data_part(APPLIED, RESPONSE, "wo_test1234567890ab");
      expect(result.invocation_id).toBeNull();
      expect(result.tool_id).toBeNull();
    });
  });
});
